<?php 
//-----------------------------------------------------
// Border Close
//-----------------------------------------------------
echo themo_return_meta_box_borders($border_show,$border_display,'bottom',$border_full_width); 
?>