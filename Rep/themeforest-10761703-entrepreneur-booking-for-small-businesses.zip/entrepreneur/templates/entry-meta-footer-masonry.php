<div class="date-meta">
	<time class="published" datetime="<?php echo get_the_time('c'); ?>"><?php echo get_the_date(); ?></time>
    <span class="is-sticky"><?php echo __('Featured Post', THEMO_TEXT_DOMAIN); ?></span>
</div>