<?php the_tags( '<div class="entry-meta meta-tags">Tags: <span class="tag-links">', ', ', '</span></div>' ); ?>


