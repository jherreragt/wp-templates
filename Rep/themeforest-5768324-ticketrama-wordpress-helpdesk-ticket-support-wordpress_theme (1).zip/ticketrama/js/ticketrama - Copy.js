/*global $:false */
// Menu

jQuery("#toggle").click(function($) {
    "use strict";
    jQuery(this).toggleClass("on");
    jQuery("#menu").slideToggle();
});


// Accordion

jQuery(function($) {
    "use strict";
    $("#accordion").accordion({collapsible: true});
});

// Box Link

jQuery(".row-more").click(function($) {
    "use strict";
    window.location = $(this).find("a").attr("href");
    return false;
});

// Fancybox
jQuery(document).ready(function($) {
    "use strict";
    $(".iframe").fancybox({
        'width': '70%',
        'height': '75%',
        'autoScale': false,
        'transitionIn': 'none',
        'transitionOut': 'none',
        'type': 'iframe'
    });
	
	$(".ajax-data, .ajax-data-menu > a").fancybox({
		'width': '70%',
        'height': '75%',
        'autoScale': false,
        'transitionIn': 'none',
        'transitionOut': 'none',
        'type': 'ajax'
	});
});