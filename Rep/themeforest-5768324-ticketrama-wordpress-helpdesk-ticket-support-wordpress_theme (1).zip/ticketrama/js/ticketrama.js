/*global $:false */
// Menu

jQuery("#toggle").click(function($) {
    "use strict";
    jQuery(this).toggleClass("on");
    jQuery("#menu").slideToggle();
});

jQuery(document).click(function(e){
    "use strict";
    var myTarget = jQuery("#menu");
	
    var clicked = e.target;
		var newobj = jQuery('#menu').find(clicked);
		var toggle = jQuery('#toggle').find(clicked);
		var ison = jQuery('#toggle').hasClass('on');
		
		if( jQuery(newobj).length || jQuery(toggle).length  ) {
			console.log('inside menu');
		}
		else {
			if( ison == true && jQuery('#menu').css('display') == 'block' ) {
				jQuery("#menu").slideUp(); 
				jQuery('#toggle').removeClass("on");
			}
		}
});
jQuery(document).on('keydown', function(e) {
	if (e.keyCode == 27) {
			jQuery("#menu").slideUp(); 
			jQuery('#toggle').removeClass("on");
	}
});


// Accordion

jQuery(function($) {
    "use strict";
    $("#accordion").accordion({collapsible: true});
});

// Box Link

jQuery(".row-more").click(function($) {
    "use strict";
    window.location = $(this).find("a").attr("href");
    return false;
});

// Fancybox
jQuery(document).ready(function($) {
    "use strict";
    $(".iframe").fancybox({
        'width': '70%',
        'height': '75%',
        'autoScale': false,
        'transitionIn': 'none',
        'transitionOut': 'none',
        'type': 'iframe'
    });
	
	$(".ajax-data, .ajax-data-menu > a").fancybox({
		'width': '70%',
        'height': '75%',
        'autoScale': false,
        'transitionIn': 'none',
        'transitionOut': 'none',
        'type': 'ajax'
	});
});