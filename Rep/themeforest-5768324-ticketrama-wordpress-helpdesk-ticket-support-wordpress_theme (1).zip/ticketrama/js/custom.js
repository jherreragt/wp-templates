
jQuery(document).ready(function($) {
    "use strict";
	
	$('form.submit-ticket, form.fw-submit-login').live('submit', function(e){
		var altn = $('.cross', this).attr('data-alt');
		var org_src = $('.cross > img', this).attr('src');
		var forms = this;
		
		var form_action = $(this).attr('action');
		var fields = $(this).serialize();
		$.fancybox.showLoading();
		$.ajax({
			url: form_action,
			type: 'POST',
			dataType:"json",
			data: fields,
			success: function(res){
				//$.fancybox('destroy');
				if( res == null ) {
					$('#response_msg').html('<p class="add-top add-left">No response</p>');
				}
				else if( res.type !== undefined ){
					if( res.type == 'success' ){
						$.fancybox('destroy');
						var html = '<div style="background-color:#fff;">'+res.msg+'</div>';
						$.fancybox(html);
						if( res.refresh === true ){
							location.reload();
						}
					}else if( res.type == 'error' ){
						$('#response_msg').html(res.msg);
					}
				}
				
				$.fancybox.hideLoading();
			}

		});
		return false;
	});
	
	
	$('.ajax-ticket-del-request').click(function(e) {
        e.preventDefault();
		var url = $(this).attr('href');
		var alt_url = $(this).attr('data-alt');
		
		if( confirm( 'Are you really want to delete this ticket?' ) ){
			$.fancybox.showLoading();
			
			$.ajax({
				url: url,
				type: 'POST',
				dataType:"json",
				success: function(res){
					if( res.type == 'success' ){
						window.location = alt_url;
					}else if( res.type == 'error' ){
						$.fancybox(res.msg);
					}
				}
			});
		}
		
		return false;
    });
	
	$('.ticket-login-form > a').click(function(e) {
        e.preventDefault();
		var url = $(this).attr('href');
		var alt_url = $(this).attr('data-alt');
	
		$.fancybox.showLoading();
	
		$.ajax({
			url: ajax_url,
			type: 'POST',
			data: 'action=fw_ajax_callback&type=login_register_form',
			success: function(res){
				$.fancybox(res);
			}
		});
		
		
		return false;
    });
});