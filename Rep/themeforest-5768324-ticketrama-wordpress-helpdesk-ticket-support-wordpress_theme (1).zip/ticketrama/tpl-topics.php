<?php 
/* Template Name: Topics */?>
<?php if( !isset( $_SESSION ) ) session_start();

$g_settings = get_option(THEME_PREFIX.'general_settings');

$_SESSION['topic_filter_categories'] = count( $_POST ) ? kvalue( $_POST, 'categories', 'all') : kvalue( $_SESSION, 'topic_filter_categories', 'all');
$_SESSION['topic_filter_sorting'] = count( $_POST ) ? kvalue( $_POST, 'sorting', 'all') : kvalue( $_SESSION, 'topic_filter_sorting', 'all');
$_SESSION['topic_filter_topic_sorting'] = count( $_POST ) ? kvalue( $_POST, 'topic_sorting', 'date') : kvalue( $_SESSION, 'topic_filter_topic_sorting', 'date');
//printr($_SESSION);?>
<?php get_header();
$settings = get_post_meta(get_the_ID(), 'wpnukes_topic_settings', true); ?>

<div id="breadcrumb">
	<div class="container">
		<div class="sixteen columns">
			<h4 class="grey bold"><?php the_title(); ?></h4>
		</div>
	</div>
</div>
<div id="topics" class="section-normal">
	<div class="container">
		<div class="sixteen columns">
			<form id="topics-filter" method="post">
				<h5 class="bold"><?php _e('FILTER', AM_THEMES); ?></h5>
				<select class="one" name="categories" onchange="jQuery('#topics-filter').submit();">
                	<?php $categories = get_categories( array( 'type'=>'topics' ) ); ?> 
					<option value="all" <?php fw_set_dropdown_valu(kvalue( $_SESSION, 'topic_filter_categories'), 'all'); ?>><?php _e('All Categories', AM_THEMES); ?></option>
                    <?php foreach( $categories as $cat ): ?>
					<option value="<?php echo kvalue( $cat, 'term_id'); ?>" <?php fw_set_dropdown_valu(kvalue( $_SESSION, 'topic_filter_categories'), $cat->term_id); ?>><?php echo kvalue( $cat, 'name'); ?></option>
                    <?php endforeach; ?>
				</select>
				<select class="two" name="sorting" onchange="jQuery('#topics-filter').submit();">
					<option value="all" <?php fw_set_dropdown_valu(kvalue( $_SESSION, 'topic_filter_sorting'), 'all'); ?>><?php _e('All Categories', AM_THEMES); ?></option>
                	<option value="popular" <?php fw_set_dropdown_valu(kvalue( $_SESSION, 'topic_filter_sorting'), 'popular'); ?>><?php _e('Popular Categories', AM_THEMES); ?></option>
					<option value="recent" <?php fw_set_dropdown_valu(kvalue( $_SESSION, 'topic_filter_sorting'), 'recent'); ?>><?php _e('Recent Categories', AM_THEMES); ?></option>

				</select>
				<select class="three" name="topic_sorting" onchange="jQuery('#topics-filter').submit();">
					<option value="date" <?php fw_set_dropdown_valu(kvalue( $_SESSION, 'topic_filter_topic_sorting'), 'date'); ?>><?php _e('Recent Topics', AM_THEMES); ?></option>
                	<option value="comment_count" <?php fw_set_dropdown_valu(kvalue( $_SESSION, 'topic_filter_topic_sorting'), 'comment_count'); ?>><?php _e('Popular Topics', AM_THEMES); ?></option>
					<option value="title" <?php fw_set_dropdown_valu(kvalue( $_SESSION, 'topic_filter_topic_sorting'), 'title'); ?>><?php _e('Topics By Title', AM_THEMES); ?></option>
				</select>
			</form>
		</div>
        
		<div class="sixteen columns">
			<h5 class="add-bottom"><?php _e('or select from category', AM_THEMES);?></h5>
		</div>

        <?php $cats = get_categories( array('include'=> implode(',', (array)kvalue($g_settings, 'topic_page_categories')) ) ); 
		
		if( $cats ):
			$i = 0;
			foreach( $cats as $c ):?>

            <div class="four columns topic-cat add-bottom <?php if($i == 0) echo 'selected';?>">
                <a href="<?php echo get_category_link($c->term_id); ?>">
                    <img src="<?php echo get_option('_wpnukes_category_'.$c->term_id.'_image'); ?>" alt="">
                    <h5 class="dubl"><?php echo $c->name; ?></h5>
                </a>
            </div>
           	<?php $i++; ?> 
        <?php endforeach;
		endif; ?>
		
        <?php $args = array( 'post_type' => 'topic', 'paged'=>get_query_var('paged') );
		$cat_order_by = 'all';
		if( kvalue( $_SESSION, 'topic_filter_sorting' ) == 'popular' ) $cat_order_by = 'count';
		else if( kvalue( $_SESSION, 'topic_filter_sorting' ) == 'recent' ) $cat_order_by = 'id';
		
		$pop_cats = get_categories( array( 'type'=>'topic', 'orderby'=>$cat_order_by, 'order'=>'desc', 'count'=>5 ) );
		$pop_cat_ids = '';
		foreach( $pop_cats as $p_cats ) $pop_cat_ids[] = $p_cats->term_id; 
		
		if( kvalue( $_SESSION, 'topic_filter_categories' ) && kvalue( $_SESSION, 'topic_filter_categories' ) !== 'all' ) $args['category__in'] = kvalue( $_SESSION, 'topic_filter_categories' );
		else if( kvalue( $_SESSION, 'topic_filter_sorting' ) && kvalue( $_SESSION, 'topic_filter_sorting' ) != 'all' ) $args['category__in'] = kvalue( $_SESSION, 'topic_filter_sorting' );
		
		if( kvalue( $_SESSION, 'topic_filter_topic_sorting' ) && kvalue( $_SESSION, 'topic_filter_topic_sorting' ) != 'date' ){
			$args['orderby'] = kvalue( $_SESSION, 'topic_filter_topic_sorting' );
			$args['order'] = 'DESC';
		}//printr($args);?>
        
		
        <?php $query = new WP_Query( $args ); //printr($query);?>
		<?php fw_the_pagination(array('total'=>$query->max_num_pages)); ?>
		<?php while( $query->have_posts() ): $query->the_post(); ?>
            <div class="sixteen columns latest-topics half-bottom">
                
                
                <div class="row-top">
                    <?php $comment = wp_count_comments( get_the_ID() );?>
                    <div class="right"><h5 class="opensans-bold"><?php echo kvalue( $comment, 'approved'); ?></h5></div>
                    <h6 class="opensans"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h6>
                </div>
                
                <div class="row-bottom">
                    <div class="right">
                        <h6 class="opensans grey"><?php printf( __('Posted by %s on %s', AM_THEMES), get_the_author(), get_the_date()); ?></h6>
                    </div>
                    <?php $com = get_comments(array('number'=>1, 'post_id'=>get_the_ID())); ?>
                    <h6 class="opensans grey"> <?php echo ( $com ) ? __('Last comment on ', AM_THEMES).date(get_option('date_format'), strtotime(kvalue( kvalue($com, 0), 'comment_date_gmt'))) : '&nbsp;'; ?></h6>
                </div>
            </div>
        <?php endwhile; ?>
		<?php fw_the_pagination(array('total'=>$query->max_num_pages)); ?>
		
	</div>
</div>

<?php get_footer(); ?>



