<?php /* Template Name: Categories */

get_header();
$settings = get_post_meta(get_the_ID(), 'wpnukes_post_settings', true);

$profile_page = fw_page_template('tpl-tickets.php');?>

<div id="breadcrumb">
    <div class="container">
        <div class="sixteen columns">
            <div class="right">
                <?php echo fw_get_searchform();?>
            </div>
            <h4 class="grey bold"><?php _e('Categories', AM_THEMES); ?></h4>
        </div>
    </div>
</div>

<div class="container section cat-wrapper">
	
        
        <?php $categories = get_categories(); //printr($categories);?>
        
        <?php foreach( $categories as $cat ): ?>
        
            <div class="twelve columns cat-box cat-list">
                <div class="four columns alpha cat-left">
                    <img alt="" src="<?php echo get_option('_wpnukes_category_'.kvalue( $cat, 'term_id').'_image'); ?>">
                </div>
                <div class="eight columns omega cat-right">
                    
                    <h5 class="cat-title"><?php echo kvalue( $cat, 'name' ); ?></h5>
                    <p><?php echo apply_filters( 'the_content', kvalue( $cat, 'category_description') ); ?></p>
                    
                    <?php $cat_posts = get_posts( array('post_type'=> array('post', 'ticket', 'topic' ), 'category' => kvalue( $cat, 'term_id')) ); //printr($cat_posts); ?>
                    
                    <ul class="cat-links">
                        <?php foreach( $cat_posts as $p ): ?>
                            <li><a href="<?php echo get_permalink( $p->ID ); ?>" title="<?php echo $p->post_title; ?>"><?php echo $p->post_title; ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                    
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php get_footer(); ?>