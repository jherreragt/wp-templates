<?php /* Template Name: Index Page */
get_header(); 
?>

<div id="breadcrumb">
    <div class="container">
        <div class="sixteen columns">
            <div class="right">
            	<?php echo fw_get_searchform(); ?>
            </div>
            <h4 class="grey bold"><?php _e('Blog / News', AM_THEMES);?></h4>
        </div>
    </div>
</div>
<div class="container dub-top">
    <div class="ten columns dub-bottom">
        <h5 class="page-hading"><?php _e('Newest posts', AM_THEMES);?></h5>
        
        <ul class="news-list">
            <?php while( have_posts() ): the_post(); ?>
            	<?php include( 'libs/blog_listing.php' ); ?>
            <?php endwhile; ?>
        </ul>
        
        <!-- POSTS NAVIGATION -->
        <?php fw_the_pagination(); ?>
    </div>
    <div class="five columns offset-by-one dub-bottom">
         <?php dynamic_sidebar( 'blog'); ?>
    </div>
</div>
<?php get_footer();?>
