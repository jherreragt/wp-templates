<?php global $_fw;?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<html <?php language_attributes(); ?>>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <!-- Mobile Specific Metas
  ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <title><?php fw_get_meta_title();//echo (is_home() || is_front_page() ) ? bloginfo('name') : wp_title(""); ?></title>
    <?php wp_head(); //Load wordpress head hooks, Our theme js and css files are loading dynamically from functions.php, custom header and favicon is loading from includes/functions.php custom_header()?>

</head>

<?php $general_settings = get_option(THEME_PREFIX.'general_settings');
	$header_background = kvalue($general_settings, 'header_background_color');
	$background_color = kvalue($general_settings, 'background_color');
?>

<body <?php body_class(''); ?> <?php echo 'style="background-color:#'.$background_color.';"' ?>>

<!-- Primary Page Layout
================================================== -->

<div id="header" <?php echo 'style="background-color:#'.$header_background.';"' ?> >
	<div class="container">
		<div class="half-left">
       
             
			<?php if(kvalue($general_settings, 'logo_type') == 'on'):?>
            	<a href="<?php echo home_url();?>"><img src="<?php echo kvalue($general_settings, 'custom_logo');?>" height="<?php echo $_fw->set_value('HEIGHT',83,true); ?>" width="<?php echo $_fw->set_value('WIDTH',302,true); ?>" ></a>
            <?php else:?>
            	<h3 class="left bold half-right"><a href="<?php echo home_url();?>"><span class="coral"><?php echo kvalue($general_settings, 'logo_text_one');?></span><span class="b-grey"><?php echo kvalue($general_settings, 'logo_text_two');?></span></a></h3>
            	<h6 class="slogan left silver"><?php bloginfo('description'); ?></h6>
			<?php endif;?>
 
		</div>
        
		<div id="navigation">
        
			<div id="toggle">
            
				<h5 class="bold white"><?php echo _e('MENU', AM_THEMES); ?></h5>
				<div class="hamburger">
					<div class="one"></div>
					<div class="two"></div>
					<div class="three"></div>
				</div>
                
			</div>

            <ul id="menu" class="menu">
            	<?php wp_nav_menu(array('theme_location'=>'main-menu', 'container'=>false, 'menu_id' => 'menu', 'items_wrap' => '%3$s')); //Main menu ?>
                <?php if(!is_user_logged_in() ): ?>
                	<li class="ticket-login-form"><a href="javascript:void(0);" ><?php _e('Register / Login', AM_THEMES); ?></a></li>
                <?php else: ?>
                	<li class=""><a href="<?php echo wp_logout_url(home_url()); ?>" ><?php _e('Logout', AM_THEMES); ?></a></li>
					<?php if( SHOW_PROFILE_LINK == 'true' ): ?>
						<?php $profile_page = fw_page_template('tpl-tickets.php'); ?>
                        <li><a href="<?php echo get_permalink( kvalue( $profile_page, 'ID') );?>" ><?php echo kvalue( $profile_page, 'post_title'); ?></a></li>
                    <?php endif; ?>
                <?php endif; ?>
                <li class="submit"><a href="<?php echo admin_url('admin-ajax.php?action=fw_ajax_callback&type=ticketform');?>" class="ajax-data"><?php _e('Submit Ticket', AM_THEMES); ?></a></li>
   			</ul>
                     
		</div>
	</div>
</div>

<div class="nav-space"></div>

