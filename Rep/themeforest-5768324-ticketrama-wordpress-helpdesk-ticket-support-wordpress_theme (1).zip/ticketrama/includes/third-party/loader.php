<?php

define('THIRD_PARTY', get_template_directory().'/includes/third-party');