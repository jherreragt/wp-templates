<?php
$options = array();



$options['section']['id'] = array(
								'label'=>'Section ID <br/><span class="sc_info">*Helpful For Links And Specific Styling</span>',
								'type'=>'text',
								'value'=>'',
								'std'=>'overview',
								);
$options['section']['bgcolor'] = array(
								'label'=>'Background Color <br/><span class="sc_info">*Use a HEX color code to assign a background color (eg.:"#ffffff" represents white)</span>',
								'type'=>'text',
								'value'=>'',
								'std'=>'#ffffff',
								);
$options['section']['class'] = array(
								'label'=>'CSS Class Of Section Container <br/><span class="sc_info">Advanced Styling</span>',
								'type'=>'text',
								'value'=>'',
								'std'=>'',
								);
$options['section_title']['title'] = array(
									'label'=>'Title <br/><span class="sc_info">Section Title</span>',
									'type'=>'text',
									'value'=>'',
									'std'=>'',
								);

//Image Shortcode
$options['img']['cc'] = array(
								'label'=>'Container Class',
								'type'=>'text',
								'value'=>'',
								'std'=>'',
								);
$options['img']['src'] = array(
								'label'=>'Image Path',
								'type'=>'text',
								'value'=>'',
								'std'=>'http://www.example.com/logo.png',
								);
$options['img']['url'] = array(
								'label'=>'URL',
								'type'=>'text',
								'value'=>'',
								'std'=>'http://www.example.com/',
								);
$options['img']['t'] = array(
								'label'=>'Title',
								'type'=>'text',
								'value'=>'',
								'std'=>'image',
								);
$options['img']['c'] = array(
								'label'=>'Image CSS Class',
								'type'=>'text',
								'value'=>'',
								'std'=>'image',
								);
$options['img']['h'] = array(
								'label'=>'Height',
								'type'=>'text',
								'value'=>'',
								'std'=>'150',
								);
$options['img']['w'] = array(
								'label'=>'Width',
								'type'=>'text',
								'value'=>'',
								'std'=>'150',
								);

								
//  Small Button

$options['small_button']['small_button_label'] = array(
								'label'=>'Button Label',
								'type'=>'text',
								'value'=>'',
								'std'=>'MORE INFO',
								);
								
$options['small_button']['small_button_link'] = array(
								'label'=>'Button Link',
								'type'=>'text',
								'value'=>'',
								'std'=>'#',
								);
								
//  Big Button

$options['big_button']['big_button_label'] = array(
								'label'=>'Button Label',
								'type'=>'text',
								'value'=>'',
								'std'=>'MORE INFO',
								);
								
$options['big_button']['big_button_link'] = array(
								'label'=>'Button Link',
								'type'=>'text',
								'value'=>'',
								'std'=>'#',
								);