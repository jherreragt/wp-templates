<?php if ( ! defined('ABSPATH')) exit('restricted access');

//SUB, DYNAMIC
$options = array();

//GENERAL SETTINGS

$options['general_settings']['background_color'] = array(
													'label'=>'Background Color',
													'type'=>'colorbox',
													'value'=>'',
													'std'=>'39404A',
													'validation'=>'required|trim',
													'define'=>'BACKGROUND_COLOR',
													'style'=>array('class'=>'fwcolorpicker bar'),
													'shorthelp'=>'Change the background color.'
												);
												
$options['general_settings']['header_background_color'] = array(
													'label'=>'Header Background Color',
													'type'=>'colorbox',
													'value'=>'',
													'std'=>'39404A',
													'validation'=>'required|trim',
													'define'=>'HEADER_BACKGROUND_COLOR',
													'style'=>array('class'=>'fwcolorpicker bar'),
													'shorthelp'=>'Change header background color.'
												);
												
$options['general_settings']['logo_type'] = array(
													'label'=>'Logo',
													'type'=>'switch',
													'shorthelp'=>'Enable/Disable logo image',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'THEMERTL',
													'style'=>array('class'=>'radiobtn checkbox')
												);

$options['general_settings']['custom_logo'] = array(
													'label'=>'Custom Logo',
													'type'=>'image',
													'shorthelp'=>'Enter the image url or click upload to use wordpress image manager.',
													'value'=>'',
													'std'=>'',
													'validation'=>'prep_url|valid_url|trim',
													'define'=>'LOGO',
													'style'=>array('class'=>'bar')
												);
												
													
$options['general_settings']['logo_dim'] = array(
													'label'=>'Logo dimension',
													'type'=>'2-input',
													'shorthelp'=>'Adjust the logo width and height, both fields are required.',
													'value'=>'',
													'define'=>'width',
													'std'=>'302',
													'define1'=>'height',
													'std_1'=>'83',
													'validation'=>'required|is_natural_no_zero|min_length[2]|max_length[4]|trim',
													'style'=>array('class'=>'ssbar')
												);

$options['general_settings']['logo_text_one'] = array(
											'label'=>'Logo Label 1',
											'type'=>'text',
											'shorthelp'=>'Your text styled like "Ticket" from "Ticketrama"',
											'value'=>'',
											'define'=>'LOGOONE',
											'std'=>'',
											'style'=>array('class'=>'bar')
										 );
										 
$options['general_settings']['logo_text_two'] = array(
											'label'=>'Logo Label 2',
											'type'=>'text',
											'shorthelp'=>'Your text styled like "Rama" from "Ticketrama"',
											'value'=>'',
											'define'=>'LOGOTWO',
											'std'=>'',
											'style'=>array('class'=>'bar')
										 );
													
$options['general_settings']['favicon'] = array(
												'label'=>'Custom favicon',
												'type'=>'image',
												'shorthelp'=>'Enter the .ico file url or click upload to use wordpress image manager <br/> <a href="http://en.wikipedia.org/wiki/Favicon" target="_blank"><strong>what is a favicon?</strong></a>',
												'value'=>'',
												'std'=>'',
												'define'=>'FAVICON',
												'validation'=>'prep_url|valid_url|trim',
												'style'=>array('class'=>'bar')
											);
											
$options['general_settings']['show_profile_link'] = array(
													'label'=>'Profile Link in Menu',
													'type'=>'switch',
													'shorthelp'=>'Show / Hide profile page link in menu.',
													'value'=>array('true'=>'', 'false'=>''),
													'std'=>'true',
													'validation'=>'',
													'define'=>'SHOW_PROFILE_LINK',
													'style'=>array('class'=>'radiobtn checkbox')
												);
$options['general_settings']['topic_page_categories'] = array(
													'label'=>'Topic Page Categories',
													'type'=>'multiselect',
													'shorthelp'=>'Please select what categories to disaplay on the topic page. Hold down CTRL / Command to select more.',
													'value'=>fw_get_categories(array('hide_empty'=>false)),
													'std'=>'Please Select categories',
													'validation'=>'',
													'define'=>'TOPIC_PAGE_CATEGORIES',
													'style'=>array('class'=>'bar')
												);
						
											
$options['general_settings']['ticket_system'] = array(
													'label'=>'Enable Ticketing',
													'type'=>'switch',
													'shorthelp'=>'Disable if you want to use the theme without the ticket system',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'TICKETING',
													'style'=>array('class'=>'radiobtn checkbox')
												);
$options['general_settings']['blog_social'] = array(
													'label'=>'Social Sharing Icons on Blog Post',
													'type'=>'switch',
													'shorthelp'=>'Enable / Disable social sharing icons on blog posts',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'BLOG_SHARING',
													'style'=>array('class'=>'radiobtn checkbox')
												);
$options['general_settings']['topic_social'] = array(
													'label'=>'Social Sharing Icons on Topics Post',
													'type'=>'switch',
													'shorthelp'=>'Enable / Disable social sharing icons on topic posts',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'TOPIC_SHARING',
													'style'=>array('class'=>'radiobtn checkbox')
												);
$options['general_settings']['ticket_social'] = array(
													'label'=>'Social Sharing Icons on Tickets Post',
													'type'=>'switch',
													'shorthelp'=>'Enable / Disable social sharing icons on ticket posts',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'TICKET_SHARING',
													'style'=>array('class'=>'radiobtn checkbox')
												);
$options['general_settings']['blog_author'] = array(
													'label'=>'Author box on Blog Post',
													'type'=>'switch',
													'shorthelp'=>'Enable / Disable Author box on blog posts',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'BLOG_AUTHOR',
													'style'=>array('class'=>'radiobtn checkbox')
												);
$options['general_settings']['topic_author'] = array(
													'label'=>'Author box on Topics Post',
													'type'=>'switch',
													'shorthelp'=>'Enable / Disable Author box on topic posts',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'TOPIC_AUTHOR',
													'style'=>array('class'=>'radiobtn checkbox')
												);
$options['general_settings']['ticket_author'] = array(
													'label'=>'Author box on Tickets Post',
													'type'=>'switch',
													'shorthelp'=>'Enable / Disable Author box on ticket posts',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'TICKET_AUTHOR',
													'style'=>array('class'=>'radiobtn checkbox')
												);
$options['general_settings']['call_action'] = array(
												'label'=>'Call To Action',
												'type'=>'text',
												'shorthelp'=>'Enter call to action number',
												'value'=>'',
												'std'=>'',
												'validation'=>'',
												'define'=>'CALL',
												'style'=>array('class'=>'bar')
												);
												
$options['general_settings']['call_message'] = array(
												'label'=>'Call To Action Message',
												'type'=>'textarea',
												'shorthelp'=>'Enter call to action message, you can use HTML tags as well.',
												'value'=>'',
												'std'=>'',
												'validation'=>'',
												'define'=>'MESSAGE',
												'style'=>array('class'=>'bar')
												);
												
$options['general_settings']['call_email'] = array(
												'label'=>'Call To Action email address',
												'type'=>'text',
												'shorthelp'=>'Enter the call to action email address.',
												'value'=>'',
												'std'=>get_option('admin_email'),
												'validation'=>'required|valid_email',
												'define'=>'EMAIL',
												'style'=>array('class'=>'bar')
												);
												
$options['general_settings']['copyright'] = array(
												'label'=>'Custom Copyright',
												'type'=>'textarea',
												'shorthelp'=>'Change the default copyright text, you can use HTML tags as well.',
												'value'=>'',
												'std'=>'',
												'validation'=>'trim|stripslashes',
												'define'=>'COPYRIGHT',
												'style'=>array('class'=>'textbox')
												 );


//HOME PAGE SETTINGS												 

$options['home_page_settings']['background'] = array(
											'label'=>'Upload Background',
											'type'=>'image',
											'shorthelp'=>'Enter the image url or click upload to use wordpress image manager.',
											'value'=>'',
											'std'=>'',
											'validation'=>'prep_url|valid_url|trim',
											'define'=>'HOME_BACKGROUND',
											'style'=>array('class'=>'bar')
										 );
										 
$options['home_page_settings']['search_box'] = array(
												'label'=>'Search Box',
												'type'=>'switch',
												'shorthelp'=>'Show or hide search box on home page',
												'value'=>array('active'=>'','inactive'=>''),
												'std'=>'active',
												'validation'=>'',
												'style'=>array('class'=>'radiobtn checkbox')
												 );
												 
$options['home_page_settings']['ticket_box'] = array(
												'label'=>'Ticket Box',
												'type'=>'switch',
												'shorthelp'=>'Show or hide submit ticket box on home page',
												'value'=>array('active'=>'','inactive'=>''),
												'std'=>'active',
												'validation'=>'',
												'style'=>array('class'=>'radiobtn checkbox')
												 );
																 

// Sidebar creator
/*$options['sidebar_settings']['category'] = 						array(
																	'label'=>'Category Sidebar',
																	'type'=>'select',
																	'shorthelp'=>'Select the sidebar for the category page',
																	'value'=>fw_sidebars_array(),
																	'std'=>'blog',
																	'validation'=>'',
																	'style'=>array('class'=>'')
																 );
$options['sidebar_settings']['archive'] = 						array(
																	'label'=>'Archive Sidebar',
																	'type'=>'select',
																	'shorthelp'=>'Select the sidebar for the archive page',
																	'value'=>fw_sidebars_array(),
																	'std'=>'blog',
																	'validation'=>'',
																	'style'=>array('class'=>'')
																 );
$options['sidebar_settings']['author'] = 						array(
																	'label'=>'Author Sidebar',
																	'type'=>'select',
																	'shorthelp'=>'Select the sidebar for the author page',
																	'value'=>fw_sidebars_array(),
																	'std'=>'blog',
																	'validation'=>'',
																	'style'=>array('class'=>'')
																 );
$options['sidebar_settings']['search'] = 						array(
																	'label'=>'Search Sidebar',
																	'type'=>'select',
																	'shorthelp'=>'Select the sidebar for category page',
																	'value'=>fw_sidebars_array(),
																	'std'=>'blog',
																	'validation'=>'',
																	'style'=>array('class'=>'')
																 );	
$options['sidebar_settings']['tags'] =	 						array(
																	'label'=>'Tags Sidebar',
																	'type'=>'select',
																	'shorthelp'=>'Select the sidebar for category page',
																	'value'=>fw_sidebars_array(),
																	'std'=>'blog',
																	'validation'=>'',
																	'style'=>array('class'=>'')
																 );


*/
// TYPOGRAPHY SETTINGS

$options['typography_settings']['font'] = array(
												'label'=>'Font',
												'type'=>'select',
												'shorthelp'=>'Select font for the content',
												'value'=>google_fonts_array()
												);
												
$options['typography_settings']['content_color'] = array(
													'label'=>'Color',
													'type'=>'colorbox',
													'value'=>'',
													'std'=>'39404A',
													'validation'=>'required|trim',
													'define'=>'COLOR_SCHEME',
													'style'=>array('class'=>'fwcolorpicker bar'),
													'shorthelp'=>'Change the color of contents according to your requirement.'
												);

$options['typography_settings']['menu_color'] = array(
													'label'=>'Menu Text Color',
													'type'=>'colorbox',
													'value'=>'',
													'std'=>'39404A',
													'validation'=>'required|trim',
													'define'=>'MENU_COLOR',
													'style'=>array('class'=>'fwcolorpicker bar'),
													'shorthelp'=>'Change the color of menues text according to your requirement.'
												);
												
// LAYOUT SETTINGS

$options['layout_settings']['breadcrumbs'] = array(
													'label'=>'Breadcrumbs',
													'type'=>'switch',
													'shorthelp'=>'Enable/Disable breadcrumbs',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'BREADCRUMBS',
													'style'=>array('class'=>'radiobtn checkbox')
													);
													
$options['layout_settings']['page_comments'] = array(
													'label'=>'Page Comments',
													'type'=>'switch',
													'shorthelp'=>'Enable/Disable page comments',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'PAGE_COMMETNS',
													'style'=>array('class'=>'radiobtn checkbox')
													);
													
$options['layout_settings']['post_comments'] = array(
													'label'=>'Post Commetns',
													'type'=>'switch',
													'shorthelp'=>'Enable/Disable post comments',
													'value'=>array('on'=>'','off'=>''),
													'std'=>'on',
													'validation'=>'',
													'define'=>'POST_COMMETNS',
													'style'=>array('class'=>'radiobtn checkbox')
													);
						 

//CONTACT PAGE SETTINGS
$options['contact_page_settings']['short_code'] = array(
												'label'=>'Short Code',
												 'type'=>'text',
												 'shorthelp'=>'Use this code to import the data applied on this page',
												 'value'=>'',
												 'std'=>'contact_form',
												 'validation'=>'trim|required',
												 'style'=>array('class'=>'bar'),
												 );
												 
$options['contact_page_settings']['contact_background'] = array(
											'label'=>'Upload Background',
											'type'=>'image',
											'shorthelp'=>'Enter the image url or click upload to use wordpress image manager.',
											'value'=>'',
											'std'=>'',
											'validation'=>'prep_url|valid_url|trim',
											'style'=>array('class'=>'bar')
										 );
												 


$options['contact_page_settings']['contact_to'] = array(
												'label'=>'Email',
												'type'=>'text',
												'shorthelp'=>'Enter the email address where you want to receive the emails.',
												'value'=>'',
												'std'=>get_option('admin_email'),
												'validation'=>'required|valid_email',
												'style'=>array('class'=>'bar')
												);
$options['contact_page_settings']['heading'] = array(
												'label'=>'Heading',
												'type'=>'text',
												'shorthelp'=>'Enter the heading to show at the top of contact page',
												'value'=>'',
												'std'=>'We are always here to help you.',
												'validation'=>'required',
												'style'=>array('class'=>'bar')
												);
$options['contact_page_settings']['company'] = array(
												'label'=>'Company Name',
												'type'=>'text',
												'shorthelp'=>'Enter the name of the company',
												'value'=>'',
												'std'=>'Ticketrama',
												'validation'=>'required',
												'style'=>array('class'=>'bar')
												);
$options['contact_page_settings']['office'] = array(
												'label'=>'Office',
												'type'=>'text',
												'shorthelp'=>'Enter the name of the office like "HeadQuaters"',
												'value'=>'',
												'std'=>'HeadQuater',
												'validation'=>'required',
												'style'=>array('class'=>'bar')
												);
$options['contact_page_settings']['subject'] = array(
												'label'=>'Subjects',
												'type'=>'text',
												'shorthelp'=>'Enter the subject of the mail, for multiple options use comma.',
												'value'=>'',
												'std'=>'Inquiry',
												'validation'=>'required|stripslashes',
												'style'=>array('class'=>'bar')
												);

$options['contact_page_settings']['redirect'] = array(
												'label'=>'Redirection',
												'type'=>'text',
												'shorthelp'=>'Enter the url where user will be redirected after successfull submission, or use blank to submit on the same page.',
												'value'=>'',
												'std'=>'',
												'validation'=>'valid_url',
												'style'=>array('class'=>'bar')
												);

$options['contact_page_settings']['success_message'] = array(
												'label'=>'Success Message',
												'type'=>'text',
												'shorthelp'=>'Enter the message you want to show after successfull submission.',
												'value'=>'',
												'std'=>'The form has been submitted successfully.',
												'validation'=>'required|stripslashes',
												'style'=>array('class'=>'bar')
												);

$options['contact_page_settings']['contact_phone'] = array(
												'label'=>'Phone',
												'type'=>'text',
												'shorthelp'=>'Enter your contact number.',
												'help'=>'',
												'value'=>'',
												'std'=>'800.123.456 [Toll-free U.S. only]',
												'validation'=>'',
												'style'=>array('class'=>'bar')
												);

$options['contact_page_settings']['contact_address'] = array(
												'label'=>'Address',
												'type'=>'textarea',
												'shorthelp'=>'Enter the address you want to show on contact us page.',
												'help'=>'',
												'value'=>'',
												'std'=>'Foundation Six 11 Harrisford St. Suite 84 Hamilton ON Canada L8K 6L7',
												'validation'=>'',
												'style'=>array('class'=>'bar')
												);

$options['contact_page_settings']['google_map'] = array(
												'label'=>'Google Map',
												'type'=>'textarea',
												'shorthelp'=>'Enter the google map iframe code or leave it blank to fetch automatically against above address field (standard sizes are 458x264).',
												'help'=>'',
												'value'=>'',
												'std'=>'',
												'validation'=>'trim|stripslashes',
												'style'=>array('class'=>'bar')
												);											


$options['contact_page_settings']['form_text'] = array(
												'label'=>'Custom HTML',
												'type'=>'textarea',
												'shorthelp'=>'Custom text to show on contact us page.',
												'help'=>'',
												'value'=>'',
												'std'=>'',
												'validation'=>'stripslashes',
												'style'=>array('class'=>'bar')
											);

$options['contact_page_settings']['form_categs'] = array(
												'label'=>'Contact Form Categories',
												'type'=>'text',
												'shorthelp'=>'Insert comma separated categories for the form categories select.',
												'help'=>'',
												'value'=>'',
												'std'=>'',
												'validation'=>'stripslashes',
												'style'=>array('class'=>'bar')
											);
											
											
// SEO SETTINGS
										 
$options['seo_meta_settings']['seo_meta_title'] = 		array(
															'label'=>'Meta Title',
															'type'=>'text',
															'shorthelp'=>'Enter meta title for home page',
															'std'=>get_bloginfo('name'),
															'extra'=>array('section_title'=>'Home Page'),
															'style'=>array('class'=>'bar')
														);
					
$options['seo_meta_settings']['site_meta_slogan'] = 	array(
															'label'=>'Site Slogan',
															'type'=>'text',
															'shorthelp'=>'Enter slogan for home page',
															'help'=>'',
															'std'=>get_bloginfo('description'),
															'style'=>array('class'=>'bar')
														);
					
$options['seo_meta_settings']['meta_description'] =     array(
															'label'=>'Meta Description',
															'type'=>'textarea',
															'shorthelp'=>'Enter meta description for home page',
															'help'=>'',
															'value'=>'',
															'std'=>'',
															'style'=>array('class'=>'bar')
														);
													
$options['seo_meta_settings']['meta_keyword'] = 		array(
															'label'=>'Meta Keyword',
															'type'=>'textarea',
															'shorthelp'=>'Enter meta keyword for home page',
															'help'=>'',
															'value'=>'',
															'std'=>'',
															'style'=>array('class'=>'bar')
														);
													
$options['seo_meta_settings']['meta_before_sep'] = 		array(
															'label'=>'Title Before Separator',
															'type'=>'select',
															'shorthelp'=>'Select meta title to appear before seperator',
															'value'=>array('site_title'=>'Site Title', 'page_title'=>'Page Title'),
															'std'=>get_bloginfo('name'),
															'extra'=>array('section_title'=>'Single Post/Page'),
														);
					
$options['seo_meta_settings']['separator'] = 			array(
															'label'=>'Separator',
															'type'=>'text',
															'shorthelp'=>'Enter separator for meta title',
															'help'=>'',
															'value'=>'',
															'std'=>'',
															'style'=>array('class'=>'bar')
														);
					
$options['seo_meta_settings']['meta_after_sep'] = 		array(
														'label'=>'Title After Separator',
														'type'=>'select',
														'shorthelp'=>'Select meta title to appear after seperator',
														'value'=>array('site_title'=>'Site Title', 'slogan' =>'Slogan', 'page_title'=>'Page/Post Title'),
														'std'=>get_bloginfo('name'),
													);
												 
// CUSTOM CODE
										 
$options['custom_settings']['header_code'] = array(
													'label'=>'Header',
													'type'=>'textarea',
													'shorthelp'=>'Add javascript or css code in &lt;head&gt; section.',
													'value'=>'',
													'std'=>'',
													'validation'=>'trim|stripslashes',
													'style'=>array('class'=>'textbox')
												 );


$options['custom_settings']['footer_code'] = array(
													'label'=>'Footer',
													'type'=>'textarea',
													'shorthelp'=>'Add javascript or HTML code in &lt;footer&gt; section.',
													'value'=>'',
													'std'=>'',
													'validation'=>'trim|stripslashes',
													'style'=>array('class'=>'textbox')
												 );
												 
$options['custom_settings']['google_analytics_code'] = array(
													'label'=>'Google Analytics',
													'type'=>'textarea',
													'shorthelp'=>'Add google analytics code.',
													'value'=>'',
													'std'=>'',
													'validation'=>'trim|stripslashes',
													'style'=>array('class'=>'textbox')
												 );
												 
$options['ticketing_settings']['twitter_api'] = array(
													'label'=>'Twitter API',
													'type'=>'text',
													'shorthelp'=>'Enter the twitter api, to get api key visit <a href="http://dev.twitter.com">Twitter Developer</a> and create new application.',
													'value'=>'',
													'std'=>'',
													'validation'=>'',
													'style'=>array('class'=>'bar')
												 );
$options['ticketing_settings']['twitter_secret'] = array(
													'label'=>'Twitter Secret key',
													'type'=>'text',
													'shorthelp'=>'Enter the twitter api secret key, to get api key visit <a href="http://dev.twitter.com">Twitter Developer</a> and create new application.',
													'value'=>'',
													'std'=>'',
													'validation'=>'',
													'style'=>array('class'=>'bar')
												 );
$options['ticketing_settings']['facebook_api'] = array(
													'label'=>'Facebook API',
													'type'=>'text',
													'shorthelp'=>'Enter the facebook api, to get api key visit <a href="http://developers.facebook.com/apps">Facebook Developer</a> and create new application.',
													'value'=>'',
													'std'=>'',
													'validation'=>'',
													'style'=>array('class'=>'bar')
												 );

										 



//define('IMAGE_PATH', get_template_directory_uri().'/images/');
$_GS = get_option(THEME_PREFIX.'general_settings');


//DEFINE CONSTANTS
foreach($options['general_settings'] as $key=>$settings)
{
	if(	! defined($settings['define']))
	{
		@define(strtoupper($settings['define']), $_GS[$key]);
		
		if($settings['type'] == '2-input')
		{
			@define(strtoupper($settings['define1']), $_GS[$key.'_1']);
		}
	}
}


//SHORTCODES REGISTERATION
$_shortcodes = (array) get_option(THEME_PREFIX.'shortcodes');
foreach($_shortcodes as $k=>$v)
{
	add_shortcode($v, $k);
}