<script type="text/javascript">
jQuery(document).ready(function(){
		jQuery('#slider-stage').carousel('#previous', '#next');
		jQuery('#viewport').carousel('#simplePrevious', '#simpleNext');  
	});

</script>

<!-- Header -->
<div id="ad-head">
    <!-- Logo -->
    <div class="ad-logo">
        <a href="http://labs.am-themes.com/"><img src="<?php echo get_template_directory_uri();?>/includes/images/logo.png" width="130" /></a>
    </div>
    <!-- Slogan
    <div class="ad-slogn">
        <h5>Ticketrama v1.0</h5>
    </div>
    -->
    <!-- Top Right Navigation -->
    <div class="ad-rightsec">
        <ul><li><a href="<?php echo admin_url();?>themes.php?page=fw_theme_options&firstlook" class="buttonone" id="importData"><span>RESET</span></a></li></ul>
    </div>
</div>
<div class="clear"></div>