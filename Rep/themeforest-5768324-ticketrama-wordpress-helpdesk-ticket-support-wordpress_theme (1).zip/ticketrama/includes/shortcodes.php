<?php 

/**
 *Class for Wordpress Shortcodes
 *
**/

class FW_Shortcodes
{
	
	var $_codes = array();
	
	/*
	 *Constructor
	*/
	function FW_Shortcodes()
	{
		//$this->_codes = $codes;
	
		//global $shortcode_tags; echo '<pre>';print_r($shortcode_tags);exit;
	}
	
	
	function add_shortcode()
	{
		include_once('shortcodes_array.php');
		foreach($options as $k=>$v) {
			add_shortcode('FW_'.$k, array($this, $k));
		}
		
		include_once('shortcodes_ticketrama.php');
		foreach($tr_options as $k=>$v) {
			add_shortcode('FW_'.$k, array($this, $k));
		}
		
		include_once('shortcodes_columns.php');
		foreach($column_options as $k=>$v) {
			add_shortcode('FW_'.$k, array($this, $k));
		}
	}
	
	function submitted_topics($atts, $content = null)
	{
		
		extract( shortcode_atts( array(
			'title_one' => 'SUBMITTED',
			'title_two' => 'TOPICS'
		), $atts ) );
		
		$count_topics = wp_count_posts('ticket');
        $published_topics = $count_topics->publish;
        $output = '';
		ob_start();
		?>
        <div class="overview-third one-third column add-bottom">
        
			<h1 class="bold d-grey left"><?php echo $published_topics;?></h1>
			<div class="left overview-sub">
				<h5 class="b-grey"><?php echo $title_one; ?></h5>
				<h5 class="b-grey"><?php echo $title_two;?></h5>
			</div>
            
        </div>   
		<?php 
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
	}
	
	function registered_users($atts, $content = null)
	{
		
		extract( shortcode_atts( array(
			'title_one' => 'REGISTERED',
			'title_two' => 'USERS'
		), $atts ) );
		
		$registred_users = count_users();
		$output = '';
		ob_start();?>
        
        <div class="overview-third one-third column add-bottom">
        
			<h1 class="bold d-grey left"><?php echo kvalue($registred_users, 'total_users');  ?></h1>
			<div class="left overview-sub">
				<h5 class="b-grey"><?php echo $title_one; ?></h5>
				<h5 class="b-grey"><?php echo $title_two;?></h5>
			</div>
            
		</div>
            
		<?php 
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
	}
	
	function solutions($atts, $content = null)
	{
		global $wpdb; 
		extract( shortcode_atts( array(
			'title' => 'SOLUTIONS'
		), $atts ) );
		
		$solutions = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts INNER JOIN $wpdb->postmeta ON post_id = ID WHERE (post_status = 'publish' AND post_type = 'ticket' AND meta_key = 'wpnukes_ticket_status' AND meta_value = 'solved')");
   		$output = '';
		ob_start();
        ?>
        <div class="overview-third one-third column add-bottom">
			<h1 class="bold d-grey left"><?php echo $solutions;?></h1>
			<div class="left overview-sub-alt">
				<h5 class="b-grey"><?php echo $title;?></h5>
			</div>
		</div>
		<?php 
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
	}
	
	function latest_topics($atts, $content = null)
	{
		global $wpdb, $post; 
		extract( shortcode_atts( array(
			'title' => 'Latest Topics',
			'number' => 'Number Topics',
			'comment_count' => true,
			'show_more'=>true
		), $atts ) );
		
		$the_query = new WP_Query( array( 'post_type' => 'topic', 'status' => 'publish', 'posts_per_page' => $number, 'order' => 'DESC', 'orderby' => 'ID') );//printr($the_query);
   		$page_template = fw_page_template('tpl-topics.php');
		$output = '';
		ob_start();
        ?>
       <div class="overview-half eight columns add-bottom">
			<div class="row"><h5 class="bold d-grey"><?php echo $title;?></h5></div>
            
            <?php while($the_query->have_posts()) : $the_query->the_post();?>
            
				<div class="row"><?php if($comment_count == 'true' ):?><h6 class="opensans-bold right"><?php echo kvalue($post, 'comment_count');?></h6><?php endif;?><h6 class="opensans blue"><a href="<?php echo get_permalink(); ?>"><?php echo get_the_title();?></a></h6></div>
            
			<?php endwhile;?>
            
            <?php wp_reset_query();?>
            
			<div class="row-more"><img class="right" src="<?php echo get_template_directory_uri();?>/images/plus.png" alt=""><h6 class="bold white"><a href="<?php echo get_permalink($page_template->post_id);?>"><?php echo __('SHOW MORE TOPICS', AM_THEMES);?></a></h6></div>
		</div>
		<?php 
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
	}
	
	
	function popular_topics($atts, $content = null)
	{
		global $wpdb, $post; 
		extract( shortcode_atts( array(
			'title' => 'Popular Topics',
			'number' => 'Number Topics',
			'comment_count' => true,
			'show_more'=>true
		), $atts ) );
		
		$the_query = new WP_Query( array('post_type' => 'topic', 'status' => 'publish', 'posts_per_page' => $number, 'orderby' => 'comment_count','order' => 'DESC' ) );//printr($the_query);
   		$page_template = fw_page_template('tpl-topics.php');
		$output = '';
		ob_start();
        ?>
       <div class="overview-half eight columns add-bottom">
			<div class="row"><h5 class="bold d-grey"><?php echo $title;?></h5></div>
            
            <?php while($the_query->have_posts()) : $the_query->the_post();?>
            
				<div class="row"><?php if($comment_count == 'true' ):?><h6 class="opensans-bold right"><?php echo kvalue($post, 'comment_count');?></h6><?php endif;?><h6 class="opensans blue"><a href="<?php echo get_permalink(); ?>"><?php echo get_the_title();?></a></h6></div>
            
			<?php endwhile;?>
            
            <?php wp_reset_query();?>
            
			<div class="row-more"><img class="right" src="<?php echo get_template_directory_uri();?>/images/plus.png" alt=""><h6 class="bold white"><a href="<?php echo get_permalink($page_template->post_id);?>"><?php echo __('SHOW MORE TOPICS', AM_THEMES);?></a></h6></div>
		</div>
		<?php 
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
	}
	
	
		
	function img($atts, $content = null)
	{
		extract( shortcode_atts( array(
			'cc' => '',
			'src' => '',
			't' => 'image',
			'url' => '',
			'w' => '',
			'h' => '',
			'c' => ''
		), $atts ) );
		
		$class = ( $c ) ? 'class="'.$c.'"' : '';
		$title = ( $t ) ? ' title="'.$t.'" alt="'.$t.'"' : '';
		$width = ( $w ) ? ' width="'.$w.'"' : '';
		$height = ( $w ) ? ' height="'.$h.'"' : '';

		$img = '<img src="'. $src .'" '. $title . $class . $width . $height. ' />';
		$img = ( $url ) ? '<a href="'.$url.'" title="'.$t.'" target="_blank">'.$img.'</a>' : $img;
		if( $cc ) return '<div class="'.$cc.'">'.$img. do_shortcode($content).'</div>';
		else return $img;

	}
	
	
	function section( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			'id' => '',
			'class' => '',
			'bgcolor' => ''
		), $atts ) );
		
		return '<div id="'.$id.'" style="background-color:'.$bgcolor.'">
					<div class="container section '.$class.'">
					'.do_shortcode( $content ).'
					</div>
				</div>';
	}
	
	function section_title( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			'title' => '',
		), $atts ) );
		
		return '<div class="text-center">
					<h4 class="title white bold">'.$title.'</h4>
				</div>';
	}
	
	function heading( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			't' => '3',
			'c'=>'',
			'h'=>''
		), $atts ) );
		
		return '<h'.$t.' class="'.$c.'">'.$h.'</h'.$t.'>';
	}
	
	
	function contact_form( $atts, $content = null )
	{
		global $_fw_callback;
		
		extract( shortcode_atts( array(
			'title' => '',
		), $atts ) );
		
		$messages = isset( $_fw_callback->messages ) ? $_fw_callback->messages : '';
		
		$contact_page_settings = get_option(THEME_PREFIX.'contact_page_settings');
		$contact_categories = explode(',', $contact_page_settings['form_categs'] );

		$form = '<div class="sixteen columns dub-bottom">
			<h5 class="bold add-bottom">'.$title.'</h5>
			'.$messages.'
			<form class="contact" action="'.get_permalink().'" method="post"">
				<div class="left">
					<input name="contact_title" type="text" placeholder="'.__('Title', AM_THEMES).'" value="'.kvalue($_POST, 'contact_title').'">
					<select name="contact_type">
						<option value="">'.__('Choose Category', AM_THEMES).'</option>';
						foreach($contact_categories as $k => $v):
							
							$form .= '<option value="'. $v .'">'. $v .'</option>';
						
						endforeach;
						
		$form .=	'</select>
					<textarea name="contact_message" placeholder="'.__('Message', AM_THEMES).'"  >'.kvalue($_POST, 'contact_message').'</textarea>
					<input name="contact_name" type="text" value="'.kvalue($_POST, 'contact_name').'" class="half" placeholder="'.__('Your name', AM_THEMES).'">
					<input name="contact_email" type="text" placeholder="'.__('Your email', AM_THEMES).'" value="'.kvalue($_POST, 'contact_email').'" class="half">
					<input type="hidden" name="fw_callback" value="contact_page" />
				</div>

					<button type="submit" class="submit">
						<h3 class="coral bold">'.__('SEND MESSAGE', AM_THEMES).'</h3>
					</button>

			</form>
		</div>';
		
		return $form;
	}
	
	function grid( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			'width' => 'six',
		), $atts ) );
		
		return '<div class="columns '.$width.'">'.do_shortcode($content).'</div>';
	}
	
	function one_third( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			'width' => 'six',
		), $atts ) );
		
		return '<div class="column one-third">'.do_shortcode($content).'</div>';
		
	}
	
	
	function two_thirds( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			'width' => 'six',
		), $atts ) );
		
		return '<div class="column two-thirds">'.do_shortcode($content).'</div>';
	}
	
	function one_fourth( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			'width' => 'six',
		), $atts ) );
		
		return '<div class="columns four">'.do_shortcode($content).'</div>';
	}
	
	
	function three_fourths( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			'width' => 'six',
		), $atts ) );
		
		return '<div class="columns twelve">'.do_shortcode($content).'</div>';
	}

	
	function button($atts, $content = null)
	{
		extract( shortcode_atts( array(
			'type' => 'submit',
			'name' => 'submit'
		), $atts ) );
		$content = ($content) ? $content : __('Submit', AM_THEMES).' &raquo;';
		
		return '<button type="'.$type.'" name="'.$name.'" class="button-class but-3">'.do_shortcode($content).'</button>';
	}
	
	
	
	function accordion( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			'heading' => '',
			'title' => '',
			'first'=>false,
			'last'=>false,
		), $atts ) );
		
		$output = '';
		if( $heading ) $output .= '<h5 class="d-grey">'.$heading.'</h5>'."\n";
		
		if( $first ) $output .= '<div id="accordion">';
		
		$output .= '<h6 class="d-grey opensans">'.$title.'</h6>'."\n";
		
		$output .= '<div>
						<p class="opensans">
						'.do_shortcode( $content ).'
						</p>
					</div>'."\n";
		if( $last ) $output .= '</div>';
		
		return $output;
	}
	
	function category( $atts, $content = null )
	{
		extract( shortcode_atts( array(
			'heading' => '',
			'ids' => '',
			'number'=>6
		), $atts ) );
		
		$output = '';
		
		if( $heading ) $output .= '<div class="text-center">
										<h4 class="title white bold">'.$heading.'</h4>
									</div>'."\n";
		
		if( $ids )
		{
			$explode = explode( ',', $ids );
			if( $explode )
			{
				foreach( $explode as $ex )
				{

					$output .= '<div class="eight columns cat-box">
									<div class="cat-left">
										<img alt="" src="'.get_option('_wpnukes_category_'.$ex.'_image').'">
										<h5>'.get_the_category_by_ID( $ex ).'</h5>
									</div>'."\n";
					
					$posts = get_posts( array( 'posts_per_page'=>$number, 'category'=>$ex, 'post_type'=>'topic' ) );
					if( $posts )
					{
						$output .= '<div class="cat-right">'."\n";
						
						foreach( $posts as $p )
						{
							$comments = wp_count_comments( kvalue($p, 'ID') );
							$output .=	'<div>
									<h6 class="opensans-bold right blue">'.kvalue( $comments, 'approved').'</h6>
									<h6 class="opensans-bold blue"><a href="'.get_permalink( kvalue($p, 'ID')).'" title="'.kvalue( $p, 'post_title').'">'.substr(kvalue( $p, 'post_title'), 0, 23).'..</a></h6> 
								</div>'."\n";
						}
						$output .= '</div>'."\n";
					}
					$output .= '</div>'."\n";
				}
			}
		}
		return $output;
	}
	
	function testimonial( $atts, $content = null )
	{
		
		extract( shortcode_atts( array(
			'author' => '',
			'company' => '',
		), $atts ) );
		
		
		return '<div class="one-third column testi-box">
					<h6 class="half-bottom opensans grey">&ldquo; '.do_shortcode( $content ).' &rdquo;</h6>
					<h6 class="opensans"><span>'.$author.', '.$company.'</span></h6>
				</div>';
	}
	
	function small_button( $atts, $content = null )
	{
		
		extract( shortcode_atts( array(
			'title' => '',
			'small_button_label' => '',
			'small_button_link' => '',
		), $atts ) );
		
			$output = '';
			
			if($small_button_label && $small_button_link) $output .= '<a href="'.$small_button_link.'" class="small-btn-inline half-right">'.$small_button_label.'</a>';
			
			return $output;
		
	}
	
	function big_button( $atts, $content = null )
	{
		
		extract( shortcode_atts( array(
			'title' => '',
			'big_button_label' => '',
			'big_button_link' => '',
		), $atts ) );
		
			$output = '';
			
			if($big_button_label && $big_button_link) $output .= '<a href="'.$big_button_link.'" class="big_btn">'.$big_button_label.'</a>';
			
			return $output;
		
	}
	
}

$FW_Shortcodes = new FW_Shortcodes;