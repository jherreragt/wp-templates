<?php
$column_options['one_third']['content'] = array(
								'label'=>'',
								'type'=>'hidden',
							
);
$column_options['two_thirds']['content'] = array(
								'label'=>'',
								'type'=>'hidden',
								);

$column_options['one_fourth']['content'] = array(
								'label'=>'',
								'type'=>'hidden',
								);
$column_options['three_fourths']['content'] = array(
								'label'=>'',
								'type'=>'hidden',
								);

$column_options['grid']['width'] = array(
								'label'=>'Width',
								'type'=>'select',
								'value'=>array('one'=>'One', 'two'=>'Two', 'three'=>'Three', 'four'=>'Four', 'five'=>'Five', 'six'=>'Six', 'seven'=>'Seven', 
								'eight'=>'Eight', 'nine'=>'Nine', 'ten'=>'Ten', 'eleven'=>'Eleven', 'twelve'=>'Twelve', 'thirteen' => 'Thirteen', 
								'fourteen'=>'Fourteen', 'fifteen'=>'Fifteen', 'sixteen'=>'Sixteen'),
								'std'=>'six',
								);
								