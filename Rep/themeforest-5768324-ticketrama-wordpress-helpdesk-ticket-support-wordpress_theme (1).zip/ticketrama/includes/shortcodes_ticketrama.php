<?php

//Submitted Topics
								
$tr_options['submitted_topics']['title_one'] = array(
								'label'=>'Title One',
								'type'=>'text',
								'value'=>'',
								'std'=>'Submitted',
								);
								
$tr_options['submitted_topics']['title_two'] = array(
								'label'=>'Title Two',
								'type'=>'text',
								'value'=>'',
								'std'=>'Topics',
								);
								
//Registered Users

$tr_options['registered_users']['title_one'] = array(
								'label'=>'Title One',
								'type'=>'text',
								'value'=>'',
								'std'=>'Registered',
								);
								
$tr_options['registered_users']['title_two'] = array(
								'label'=>'Title Two',
								'type'=>'text',
								'value'=>'',
								'std'=>'Users',
								);
								
//Solutions

$tr_options['solutions']['title'] = array(
								'label'=>'Title',
								'type'=>'text',
								'value'=>'',
								'std'=>'Solutions',
								);
								
							
//Latest Topics

$tr_options['latest_topics']['title'] = array(
								'label'=>'Title',
								'type'=>'text',
								'value'=>'',
								'std'=>'Latest Topics',
								);
								
$tr_options['latest_topics']['number'] = array(
								'label'=>'Total Topics',
								'type'=>'text',
								'value'=>'',
								'std'=>5,
								);
								
$tr_options['latest_topics']['comment_count'] = array(
								'label'=>'Show Number of Articles',
								'type'=>'select',
								'value'=>array('true'=>'True', 'false'=>'False'),
								'std'=>'true',
								);
								
$tr_options['latest_topics']['more_topics'] = array(
								'label'=>'Show More topics',
								'type'=>'select',
								'value'=>array('true'=>'True', 'false'=>'False'),
								'std'=>'true',
								);
								
//Popular Topics

$tr_options['popular_topics']['title'] = array(
								'label'=>'Title',
								'type'=>'text',
								'value'=>'',
								'std'=>'Latest Topics',
								);
								
$tr_options['popular_topics']['number'] = array(
								'label'=>'Total Topics',
								'type'=>'text',
								'value'=>'',
								'std'=>5,
								);
								
$tr_options['popular_topics']['comment_count'] = array(
								'label'=>'Show Number of Articles',
								'type'=>'select',
								'value'=>array('true'=>'True', 'false'=>'False'),
								'std'=>'true',
								);
								
$tr_options['popular_topics']['more_topics'] = array(
								'label'=>'Show More topics',
								'type'=>'select',
								'value'=>array('true'=>'True', 'false'=>'False'),
								'std'=>'true',
								);
								
//FAQ's

$tr_options['accordion']['heading'] = array(
								'label' => 'Accordian Heading',
								'type' => 'text',
								'value' => '',
								'std' => ''
								);
								
$tr_options['accordion']['title'] = array(
								'label' => 'Title',
								'type' => 'text',
								'value' => '',
								'std' => ''
								);
								
$tr_options['accordion']['content'] = array(
								'label' => 'Content',
								'type' => 'textarea',
								'value' => '',
								'std' => ''
								);
								
$tr_options['accordion']['first'] = array(
								'label' => 'First',
								'type' => 'select',
								'value' => array('true'=>'True','false'=>'false'),
								'std' => ''
								);
								
$tr_options['accordion']['last'] = array(
								'label' => 'Last',
								'type' => 'select',
								'value' => array('true'=>'First','last'=>'Last'),
								'std' => ''
								);
								
// Category
								
$tr_options['category']['heading'] = array(
								'label' => 'Heading',
								'type' => 'text',
								'std' => ''
								);
$tr_options['category']['ids'] = array(
								'label' => 'Categories',
								'type' => 'multiselect',
								'value' => fw_get_categories(array('hide_empty'=>0)),
								'std' => ''
								);
$tr_options['category']['number'] = array(
								'label' => 'Number of Topics',
								'type' => 'text',
								'std' => ''
								);
								
// Testimonials

$tr_options['testimonial']['author'] = array(
								'label' => 'Author',
								'type' => 'text',
								'std' => ''
								);
$tr_options['testimonial']['company'] = array(
								'label' => 'Company',
								'type' => 'text',
								'std' => ''
								);
$tr_options['testimonial']['content'] = array(
								'label' => 'Content',
								'type' => 'textarea',
								'std' => ''
								);

// Contact Us
$tr_options['contact_form']['title'] = array(
								'label'=>'Heading',
								'type'=>'text',
								'value'=>'',
								'std'=>'Contact Us',
								);
