<?php
include_once('includes/shortcodes.php');
include_once('includes/shortcoder.php');

// Shorcodes Editor

if(isset($_GET['fw_editor_action']) && $_GET['fw_editor_action'] == 'shortcode')
{
	include_once('includes/sc-editor.php');exit;
}
$FW_Shortcodes->add_shortcode();


get_template_part( 'libs/post_types' );
get_template_part( 'libs/taxonomy/taxonomy' );
get_template_part( 'libs/ajax_handler' );
get_template_part( 'libs/metaboxes/metaboxes' );
//get_template_part( 'libs/opauth-twitter/TwitterStrategy' );

if( kvalue( $_GET, 'twitter_signin' ) ) {
	twitter_authorization();
}

/**
 * this function either prints or return the pagination of any archive/listing page.
 *
 * @param	array	$args	Array of arguments
 * @param	bolean	$echo	whether print or return the output.
 *
 * @return	string	Prints or return the pagination output.
 */
function fw_the_pagination($args = array(), $echo = 1)
{
	
	global $wp_query;
	
	$default =  array('base' => str_replace( 99999, '%#%', esc_url( get_pagenum_link( 99999 ) ) ), 'format' => '?paged=%#%', 'current' => max( 1, get_query_var('paged') ),
						'total' => $wp_query->max_num_pages, 'next_text' => '&nbsp;', 'prev_text' => '&nbsp;', 'type'=>'array');
						
	$args = wp_parse_args($args, $default);
	$pages = paginate_links($args);
	$pagination = '';
	
	if( $pages ){
		$pagination = '<div class="pagination">
						<div>';
		foreach( $pages as $p )
		{
			$pagination .= '<h6>'.$p.'</h6>';
		}
		$pagination .= '</div></div>';
	}

	if($pagination)
	{
		if($echo) echo $pagination;
		return $pagination;
	}
}

if( !function_exists('fw_page_template') )
{
	function fw_page_template( $tpl )
	{
		$page = get_pages(array('meta_key' => '_wp_page_template','meta_value' => $tpl));
		if($page) return current( (array)$page);
		else return false;
	}
}


function twitter_sign_in( $data )
{
	global $wpdb;
	
	$res = $wpdb->get_row( "SELECT * FROM ".$wpdb->prefix."usermeta WHERE meta_key = 'twitter_user_id' AND meta_value = ".kvalue($data, 'user_id') );

	$existing = ( $res ) ? get_userdata( kvalue( $res, 'user_id' ) ) : false;

	if( isset($existing->ID))
	{
		wp_set_auth_cookie( $existing->ID );
		return true;
	}
	
	if( !isset($existing->ID) && kvalue($data, 'screen_name'))
	{
		$username = (!username_exists(kvalue($data, 'screen_name'))) ? kvalue( $data, 'screen_name') : kvalue( $data, 'screen_name').kvalue( $data, 'user_id');
		$password = wp_generate_password( 12, true );
		
		$options = array('user_login'=>$username, 'user_pass'=>$password, 'user_nicename'=>$username, 'role' => get_option('default_role'));

		$user_id = '';
		
		$user_id = wp_insert_user($options);
		
		
		if( !is_wp_error($user_id))
		{
			//update_user_meta( $user_id, 'user_gender', kvalue($_POST, 'gender') );
			update_user_meta( $user_id, 'twitter_user_id', kvalue($data, 'user_id') );
			wp_set_auth_cookie( $user_id );
			$message = sprintf( __("Your new user is created, Details are \nusername is: \t %s \npassword is: \t %s", AM_THEMES), kvalue($_POST, $username), $password );

			//wp_new_user_notification( $user_id, $password );

			//exit('success');
			return true;
		}
		return false;
	}
	return false;
}


function twitter_authorization()
{
	$settings = get_option(THEME_PREFIX.'ticketing_settings');

	if( !kvalue( $settings, 'twitter_api') ) return false;
	
	require_once ('includes/codebird.php');
	Codebird::setConsumerKey( kvalue( $settings, 'twitter_api'), kvalue( $settings, 'twitter_secret')); // static, see 'Using multiple Codebird instances'
	
	$cb = Codebird::getInstance();
	
	//$cb->setToken('92776433-sHsKQFxAKlA3WP3w3T4z93Jc1Kp3q4CgoYB7dnfgm', 'ogIIrbtUNhY3hpscUmE3KynqGoHbLBh1H64h7I1tfZ0');
	
	if( !isset($_SESSION) ) session_start();
	//session_destroy();exit;
	//printr($_SESSION);
	if (! isset($_SESSION['oauth_token'])) {
		// get the request token
		$reply = $cb->oauth_requestToken(array(
			'oauth_callback' => 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']
		));
	//printr($reply);
		// store the token
		$cb->setToken($reply->oauth_token, $reply->oauth_token_secret);
		$_SESSION['oauth_token'] = $reply->oauth_token;
		$_SESSION['oauth_token_secret'] = $reply->oauth_token_secret;
		$_SESSION['oauth_verify'] = true;
	
		// redirect to auth website
		$auth_url = $cb->oauth_authorize();
		header('Location: ' . $auth_url);
		die();
	
	} elseif (isset($_GET['oauth_verifier']) && isset($_SESSION['oauth_verify'])) {
		// verify the token
		$cb->setToken($_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);
		unset($_SESSION['oauth_verify']);
	
		// get the access token
		$reply = $cb->oauth_accessToken(array(
			'oauth_verifier' => $_GET['oauth_verifier']
		));
		if( $reply && kvalue( $reply, 'screen_name') ){
			//printr($reply);
			twitter_sign_in( $reply );
			// store the token (which is different from the request token!)
			$_SESSION['oauth_token'] = $reply->oauth_token;
			$_SESSION['oauth_token_secret'] = $reply->oauth_token_secret;
			$_SESSION['twitter_user_id'] = $reply->user_id;
			$_SESSION['twitter_screen_name'] = $reply->screen_name;
		}
		// send to same URL, without oauth GET parameters
		wp_redirect(home_url());
		die();
	}
	if( kvalue( $_SESSION, 'twitter_user_id' ) ){
		twitter_sign_in( array('user_id'=>kvalue( $_SESSION, 'twitter_user_id' ), 'screen_name'=>kvalue( $_SESSION, 'twitter_screen_name' )) );
		// assign access token on each page load
		$cb->setToken($_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);
		wp_redirect(home_url());
		die();
	}
}



add_action( 'add_meta_boxes_comment', 'extend_comment_add_meta_box' );
add_action( 'edit_comment', 'extend_comment_edit_metafields' );
add_action( 'comment_post', 'save_comment_meta_data' );

function extend_comment_add_meta_box() {
    add_meta_box( 'title', __( 'Comment Metadata - Extend Comment', AM_THEMES ), 'extend_comment_meta_box', 'comment', 'normal', 'high' );
}

function extend_comment_meta_box( $comment )
{
	$staff = get_comment_meta( kvalue( $comment, 'comment_ID' ), 'support_staff', true );
	$solved = get_comment_meta( kvalue( $comment, 'comment_ID' ), 'solved', true );
	//printr($comment);
	$c = ( $staff == 'true' ) ? 'checked="checked"' : '';
	$d = ( $solved == 'true' ) ? 'checked="checked"' : '';
	
	wp_nonce_field( 'extend_comment_update', 'extend_comment_update', false );

	echo '<label><input type="checkbox" '.$c.' name="support_staff" value="true"> '.__('Support Staff', AM_THEMES).' </label>';
	echo '<label><input type="checkbox" '.$d.' name="solved" value="true"> '.__('Solved', AM_THEMES).' </label>';
}

function extend_comment_edit_metafields( $comment_id )
{

	//printr($_POST);
	if( ! isset( $_POST['extend_comment_update'] ) || 
	! wp_verify_nonce( $_POST['extend_comment_update'], 'extend_comment_update' ) ) return;
	
	if( $staff = kvalue( $_POST, 'support_staff' ) ) update_comment_meta( $comment_id, 'support_staff', 'true' );
	else update_comment_meta( $comment_id, 'support_staff', 'false' );
	
	if( $solved = kvalue( $_POST, 'solved' ) ) update_comment_meta( $comment_id, 'solved', 'true' );
	else update_comment_meta( $comment_id, 'solved', 'false' );
}

function save_comment_meta_data( $comment_id )
{
	$user = wp_get_current_user();
	$comment = get_comment( $comment_id );
	$post_meta = get_post_meta( kvalue( $comment, 'comment_post_ID'), 'wpnukes_ticket_settings', true );
	$post_meta['ticket_status'] = ( kvalue( $_POST, 'solved' ) ) ? 'solved' : 'pending';
	//echo '<pre>';print_r($user);
	//printr($_POST);
	$role = kvalue( kvalue( $user, 'roles' ), '0' );


	if( $role == 'support' || $role == 'administrtor' ) {
		update_comment_meta( $comment_id, 'support_staff', 'true' );
	}
	else update_comment_meta( $comment_id, 'support_staff', 'false' );
	
	if( kvalue( $_POST, 'solved' ) ) {
		update_comment_meta( $comment_id, 'solved', 'true' );
		update_post_meta( kvalue( $comment, 'comment_post_ID'), 'wpnukes_ticket_status', 'solved' );
	}
	else {
		update_comment_meta( $comment_id, 'solved', 'false' );
		update_post_meta( kvalue( $comment, 'comment_post_ID'), 'wpnukes_ticket_status', 'pending' );
	}
	update_post_meta( kvalue( $comment, 'comment_post_ID'), 'wpnukes_ticket_settings', $post_meta );
	
}


/**
 * Outputs a complete commenting form for use within a template.
 * Most strings and form fields may be controlled through the $args array passed
 * into the function, while you may also choose to use the comment_form_default_fields
 * filter to modify the array of default fields if you'd just like to add a new
 * one or remove a single field. All fields are also individually passed through
 * a filter of the form comment_form_field_$name where $name is the key used
 * in the array of fields.
 *
 * @since 3.0.0
 * @param array $args Options for strings, fields etc in the form
 * @param mixed $post_id Post ID to generate the form for, uses the current post if null
 * @return void
 */
function fw_comment_form( $args = array(), $post_id = null ) {
	if ( null === $post_id )
		$post_id = get_the_ID();
	else
		$id = $post_id;

	$commenter = wp_get_current_commenter();
	$user = wp_get_current_user();
	$user_identity = $user->exists() ? $user->display_name : '';
	$role = kvalue( kvalue( $user, 'roles' ), '0' );
	

	$args = wp_parse_args( $args );
	if ( ! isset( $args['format'] ) )
		$args['format'] = current_theme_supports( 'html5', 'comment-form' ) ? 'html5' : 'xhtml';

	$req      = get_option( 'require_name_email' );
	$aria_req = ( $req ? " aria-required='true'" : '' );
	$html5    = 'html5' === $args['format'];
	$fields   =  array(
		'facebook' => '<a class="half facebook" href="javascript:void(0);" onclick="fblogin();"><span>'.__('Sign In with Facebook', AM_THEMES).'</span></a>',
		'twitter' => '<a class="half twitter" href="'.home_url().'/?twitter_signin=true"><span>'.__('Sign In with Twitter', AM_THEMES).'</span></a>',
		'author' => '<input class="half" id="" placeholder="'.__('Name', AM_THEMES).' *" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' />',
		'email'  => '<input class="half" id="email" placeholder="'.__('Email', AM_THEMES).' *" name="email" ' . ( $html5 ? 'type="email"' : 'type="text"' ) . ' value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' />',

	);

	$textarea_class = is_user_logged_in() ? 'border-top' : '';
	
	$required_text = sprintf( ' ' . __('Required fields are marked %s', AM_THEMES), '<span class="required">*</span>' );
	$defaults = array(
		'fields'               => apply_filters( 'comment_form_default_fields', $fields ),
		'comment_field'        => '<textarea class="'.$textarea_class.'" id="comment" placeholder="' . _x( 'Message', 'Messages', AM_THEMES ) . '" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>',
		'must_log_in'          => '<p class="must-log-in">' . sprintf( __( 'You must be <a href="%s">logged in</a> to post a comment.', AM_THEMES ), wp_login_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
		'logged_in_as'         => '<p class="logged-in-as">' . sprintf( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>', AM_THEMES ), get_edit_user_link(), $user_identity, wp_logout_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
		'comment_notes_before' => '<p class="comment-notes">' . __( 'Your email address will not be published.', AM_THEMES ) . ( $req ? $required_text : '' ) . '</p>',
		'comment_notes_after'  => '<p class="form-allowed-tags">' . sprintf( __( 'You may use these <abbr title="HyperText Markup Language">HTML</abbr> tags and attributes: %s', AM_THEMES ), ' <code>' . allowed_tags() . '</code>' ) . '</p>',
		'id_form'              => 'commentform',
		'id_submit'            => 'submit',
		'title_reply'          => __( 'Add comment', AM_THEMES ),
		'title_reply_to'       => __( 'Leave a Reply to %s', AM_THEMES ),
		'cancel_reply_link'    => __( 'Cancel reply', AM_THEMES ),
		'label_submit'         => __( 'POST COMMENT', AM_THEMES ),
		'format'               => 'xhtml',
	);

	$args = wp_parse_args( $args, apply_filters( 'comment_form_defaults', $defaults ) );

	?>
		<?php if ( comments_open( $post_id ) ) : ?>
			<?php do_action( 'comment_form_before' ); ?>
			<div id="respond" class="comment-respond">
				<h5 id="reply-title" class="opensans-bold half-bottom grey"><?php comment_form_title( $args['title_reply'], $args['title_reply_to'] ); ?> <small><?php cancel_comment_reply_link( $args['cancel_reply_link'] ); ?></small></h5>
				<?php if ( get_option( 'comment_registration' ) && !is_user_logged_in() ) : ?>
					<?php echo $args['must_log_in']; ?>
					<?php do_action( 'comment_form_must_log_in_after' ); ?>
				<?php else : ?>
					<form action="<?php echo site_url( '/wp-comments-post.php' ); ?>" method="post" id="<?php echo esc_attr( $args['id_form'] ); ?>" class="comment-form respond"<?php echo $html5 ? ' novalidate' : ''; ?>>
						<?php do_action( 'comment_form_top' ); ?>
						<?php if ( is_user_logged_in() ) : ?>
							<?php echo apply_filters( 'comment_form_logged_in', $args['logged_in_as'], $commenter, $user_identity ); ?>
							<?php do_action( 'comment_form_logged_in_after', $commenter, $user_identity ); ?>
						<?php else : ?>
							<?php echo $args['comment_notes_before']; ?>
							<?php
							do_action( 'comment_form_before_fields' );
							foreach ( (array) $args['fields'] as $name => $field ) {
								echo apply_filters( "comment_form_field_{$name}", $field ) . "\n";
							}
							do_action( 'comment_form_after_fields' );
							?>
						<?php endif; ?>
                       <?php if( $role == 'support' || $role == 'administrator' ){
                            echo '<p class="comment-form-solved"><label for="solved">' . __( 'Solved', AM_THEMES ) . ' <input type="checkbox" id="solved" name="solved" value="true" /></label> ' .
                                                '</p>';
                        } ?>
						<?php echo apply_filters( 'comment_form_field_comment', $args['comment_field'] ); ?>
						<?php echo $args['comment_notes_after']; ?>
						<p class="form-submit">
							<button class="medium-btn" name="submit" type="submit" id="<?php echo esc_attr( $args['id_submit'] ); ?>" ><?php echo esc_attr( $args['label_submit'] ); ?></button>
							<?php comment_id_fields( $post_id ); ?>
						</p>
						<?php do_action( 'comment_form', $post_id ); ?>
					</form>
				<?php endif; ?>
			</div><!-- #respond -->
			<?php do_action( 'comment_form_after' ); ?>
		<?php else : ?>
			<?php do_action( 'comment_form_comments_closed' ); ?>
		<?php endif; ?>
	<?php
}


/**
 * A callback function of comments listing
 * 
 * @param	object	$comment	containg a list of comments
 * @param	array	$args		An array of arguments to merge with defaults.
 * @param	int		$depth		Containing the reply depth level.
 */

function fw_list_comments($comment, $args, $depth)
{

	$GLOBALS['comment'] = $comment;
	$solution = get_comment_meta( kvalue( $comment, 'comment_ID'), 'solved', true);
	$staff = get_comment_meta( kvalue( $comment, 'comment_ID'), 'support_staff', true);
	
	$user_obj = get_userdata( kvalue( $comment, 'user_id' ) );
	$user_role = ( $user_obj ) ? kvalue( kvalue( $user_obj, 'roles' ), '0' ) : '';
	
	
	if(get_comment_type() == 'comment'):?>
        <div class="comment <?php echo ( $solution == 'true' ) ? 'ticket-solution' : ''; ?>" id="comment-<?php comment_ID();?>">
        	
			<?php /** check if this comment author not have approved comments befor this */
			if($comment->comment_approved == '0' ) : ?>
				<em><?php /** print message below */
				_e( 'Your comment is awaiting moderation.', AM_THEMES ); ?></em>
				<br />
			<?php endif; ?>
            
            <p class="opensans grey half-bottom"><?php comment_text(); /** print our comment text */ ?> </p>
            
            <div class="clearfix">
                <h6 class="opensans left">
                	<?php if( $staff == 'true' || $user_role == 'administrator' ): ?>
                    	<?php _e('by', AM_THEMES); ?> <span class="staff-author"><?php _e('Support Staff', AM_THEMES); ?></span>
                    <?php else: ?>
                    	@<?php echo get_comment_author_link(); ?>
                    <?php endif; ?>
                    , <?php comment_date( get_option( 'date_format' ) );?>
                </h6>
                
                <?php if( $solution == 'true' ): ?>
                	<span class="solution-label opensans-bold right half-left"><?php _e('Solution', AM_THEMES); ?></span>
                <?php endif; ?>
                
                 <?php if( $solution != 'true' ): ?>
                    <span class="right">
                        <?php /** check if thread comments are enable then print a reply link */
                        comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
                    </span>
                <?php endif; ?>
                
            </div>
        
                
	<?php
	endif;
}


add_filter('user_contactmethods', 'newuserfilter');

function newuserfilter($test)
{
	$array =array('facebook' => 'Facebook', 'twitter'=> 'Twitter');
	$test = array_merge($array, $test);
	return $test;
}

function fw_set_dropdown_valu($v, $val)
{
	echo ( $v == $val ) ? 'selected="selected"' : '';
}

function fw_get_meta_title()
{
	global $wp_query;
	$seo_settings = get_option(THEME_PREFIX.'seo_meta_settings');
	$title = '';
	$meta_after = '';
	$home_title = kvalue($seo_settings, 'meta_title') ? kvalue($seo_settings, 'meta_title') : get_bloginfo( 'name' );
	$slogan = kvalue($seo_settings, 'site_slogan') ? kvalue($seo_settings, 'site_slogan') : get_bloginfo( 'description' );
	$sep = kvalue($seo_settings, 'separator') ? kvalue($seo_settings, 'separator') : ' - ';

	$meta_before = (kvalue($seo_settings, 'meta_before_sep') == 'site_title') ? $home_title : wp_title( '', false );
	if( kvalue($seo_settings, 'meta_after_sep') == 'site_title' ) $meta_after = $home_title;
	elseif( kvalue($seo_settings, 'meta_after_sep') == 'slogan' ) $meta_after = get_bloginfo( 'description' );
	elseif( kvalue($seo_settings, 'meta_after_sep') == 'page_title' ) $meta_after = wp_title( '', false );

	if(is_home() || is_front_page()){
		
		$title = $home_title . $sep . $slogan;
	}else{
		$title = $meta_before . $sep . $meta_after;
	}

	echo $title;
}

function fw_get_searchform()
{?>
	<form class="headsearch" method="get">
        <input type="text" onfocus="if (this.value == '<?php _e('search here', AM_THEMES );?>') {
                    this.value = ''
                }" onblur="if (this.value == '') {
                    this.value = '<?php _e('search here', AM_THEMES );?>'
                }" value="<?php _e('search here', AM_THEMES );?>" class="headsearch" name="s">
	</form>
<?php	
}



add_action('personal_options', 'fw_user_profile_personal_options');
//add_action('profile_personal_options', 'fw_user_profile_personal_options');
add_action('edit_user_profile_update', 'fw_user_profile_personal_options_update');
add_action('personal_options_update', 'fw_user_profile_personal_options_update');

function fw_user_profile_personal_options( $profile )
{
	include( 'libs/profile_fields.php');
}

function fw_user_profile_personal_options_update( $user_id )
{
	if( $image = kvalue( $_POST, 'ad_image' ) ){
		update_user_meta( $user_id, '_profile_image', $image );
	}
}



