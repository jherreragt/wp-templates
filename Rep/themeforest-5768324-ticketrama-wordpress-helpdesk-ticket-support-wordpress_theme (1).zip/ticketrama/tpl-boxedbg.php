<?php /* Template Name: Boxed Backgrounds */
get_header(); 
?>

<div id="breadcrumb">
	<div class="container">
		<div class="sixteen columns">
			<div class="right">
				<?php echo fw_get_searchform();?>
			</div>
			<h4 class="grey bold"><?php the_title(); ?></h4>
		</div>
	</div>
</div>

<div class="section-normal" id="hello">
	<div class="container dub-bottom">
		<figure class="media-object">
              <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail(); ?></a>
          </figure>
		<?php while( have_posts() ): the_post();
               the_content(); 
          endwhile;?>
   	</div>
</div>


<?php get_footer(); ?>