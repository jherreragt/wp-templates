<?php get_header();
$settings = get_option(THEME_PREFIX.'sidebar_settings'); ?>

<div id="breadcrumb">
    <div class="container">
        <div class="sixteen columns">
            <div class="right">
                <?php echo fw_get_searchform();?>
            </div>
            <h4 class="grey bold">
            	<?php
					if ( is_day() ) :
						printf( __( 'Daily Archives: %s', AM_THEMES ), get_the_date() );
					elseif ( is_month() ) :
						printf( __( 'Monthly Archives: %s', AM_THEMES ), get_the_date( _x( 'F Y', 'monthly archives date format', AM_THEMES ) ) );
					elseif ( is_year() ) :
						printf( __( 'Yearly Archives: %s', AM_THEMES ), get_the_date( _x( 'Y', 'yearly archives date format', AM_THEMES ) ) );
					else :
						_e( 'Archives', AM_THEMES );
					endif;
				?>
            </h4>
        </div>
    </div>
</div>
<div class="container dub-top">
    <div class="ten columns dub-bottom">
        <h5 class="page-hading"><?php _e('Newest posts', AM_THEMES );?></h5>
        
        <ul class="news-list">
            <?php while( have_posts() ): the_post(); ?>
            	<?php include( 'libs/blog_listing.php' ); ?>
            <?php endwhile; ?>
        </ul>
        
        <!-- POSTS NAVIGATION -->
        <?php fw_the_pagination(); ?>
    </div>
    <div class="five columns offset-by-one dub-bottom">
        <?php dynamic_sidebar( kvalue( $settings, 'archive', 'blog') ); ?>
    </div>
</div>
<?php get_footer();?>
