<?php if ( ! defined('ABSPATH')) exit('restricted access');

/** Theme settings note: don't remove it */
define('AM_THEMES', 'ticketrama');
define('FRAME_WORK', 'Version 1.0');
define('THEME_URL', get_template_directory_uri());
define('THEME_PREFIX', 'fw_ticketrama_'); //UNIQUE IDENTY MUST CONTAIN _ AT THE END

/** Initialize the WPnukes Apanel */
//require_once('includes/launcher.php');


add_theme_support('menus');

add_theme_support('widgets');


/** Load the default functions after theme setup */
add_action('after_setup_theme', 'wl_theme_setup');

function wl_theme_setup()
{
	global $column_options, $tr_options, $options, $_validation, $_dynamics, $_dynamic_headings, $wp_registered_sidebars;;
	
	fw_widget_init();
	
	include_once('includes/options.php');
	

	get_template_part('theme_functions');


	
	/** Add languages support */
	load_theme_textdomain(AM_THEMES, get_template_directory()  .'/languages');
	
	/** Allows theme developers to link a custom stylesheet file to the TinyMCE visual editor. default(style.css) */
	add_editor_style();
	
	add_role('support', __('Support Staff', AM_THEMES), array('read' => true, 'edit_posts' => true, 'delete_pots' => false));
		
}

add_image_size( '600x260', 600, 260, true );

//Register custom menu
$menus = array( 'main-menu' => 'Main Menu');
register_nav_menus($menus);

/** Set the width of images and content. Should be equal to the width the theme	*/
$content = (isset($content_width)) ? $content_width : 613;

/** Add feed link support */
add_theme_support( 'automatic-feed-links' );

/** Post thumnail Support and add new sizes that themes is required */
add_theme_support('post-thumbnails');

//Example Code
//add_image_size( 'post-image1', 363, 201, true );

/** include theme scripts and styles */
get_template_part('libs/scripts_styles');

/** include theme breadcrumbs */
get_template_part('libs/breadcrumbs');

/** include theme widgets */
get_template_part('libs/widgets');


function fw_widget_init()
{
	$settings = get_option( THEME_PREFIX.'sidebar_settings');
	register_sidebar( array(
		'name' => 'Blog Sidebar',
		'id' => 'blog',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h6 class="grey">',
		'after_title' => '</h4>',
	) );
	register_sidebar( array(
		'name' => 'Footer Sidebar',
		'id' => 'footer_sidebar',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h6 class="grey">',
		'after_title' => '</h4>',
	) );

	if( $settings && is_array( kvalue( $settings, 'DYNAMIC' ) ) )
	{
		foreach( kvalue( $settings, 'DYNAMIC' ) as $dynamic ){
			$name = kvalue( $dynamic, 'name');
			register_sidebar( array(
				'name' => $name,
				'id' => texttoslug($name),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget' => "</div>",
				'before_title' => '<h6 class="grey">',
				'after_title' => '</h4>',
			) );
		}
	}
	

}


function custom_header()
{
	$general_settings = get_option( THEME_PREFIX.'general_settings');
	$typography_settings = get_option( THEME_PREFIX.'typography_settings');
	$custom_settings = get_option( THEME_PREFIX.'custom_settings');
	$custom_style = '';
	if(kvalue($general_settings, 'favicon'))
		echo '<link id="page_favicon" href="'.kvalue($general_settings, 'favicon').'" rel="icon" type="image/x-icon" />'."\n";
	if(kvalue($general_settings, 'favicon'))
		echo '<link href="http://fonts.googleapis.com/css?family=" rel="stylesheet" type="text/css">'."\n";
	if(kvalue($typography_settings, 'font'))
		echo '<link href="http://fonts.googleapis.com/css?family='.kvalue($typography_settings, 'font').'" rel="stylesheet" type="text/css">'."\n";
	if(kvalue($typography_settings, 'menu_color'))
		$custom_style .= '#menu li a{color:#'.kvalue($typography_settings, 'menu_color').' !important;}'."\n";	
	if(kvalue($typography_settings, 'menu_color'))
		$custom_style .= 'p{color:#'.kvalue($typography_settings, 'content_color').' !important;}'."\n";
	/*if(kvalue($typography_settings, 'font'))
		$custom_style .= 'body{font-family:'.kvalue($typography_settings, 'font').' !important;}'."\n";*/
		
	echo '<link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800" rel="stylesheet" type="text/css">'."\n";
		
	echo '<style>'.$custom_style.'</style>'."\n";
	
	if(kvalue($custom_settings, 'header_code'))
		echo kvalue($custom_settings, 'header_code');
}

function custom_footer()
{
	
	$custom_settings = get_option( THEME_PREFIX.'custom_settings');
	if(kvalue($custom_settings, 'footer_code'))
		echo kvalue($custom_settings, 'footer_code');
	if(kvalue($custom_settings, 'google_analytics_code'))
		echo kvalue($custom_settings, 'google_analytics_code');
		
}



add_action('wp_head', 'custom_header', 10);
add_action('wp_footer', 'custom_footer', 50);

/**
  * Function to check whether a key is exists in array, Otherwise return default value
  * @param arr  array an array from which a key need to be checked
  * @param key  string A string need to be checked either exists in an array or not
  * @param default string/array If the key is not exists in given array then the default value will be returned
  * 
  * @return string/array Either array or string will be returned.
  */
  
//@TODO: we have to add the support of xpath
function kvalue( $obj, $val, $def = '' )
{
	if( is_array($obj) ) 
	{
		if( isset( $obj[$val] ) ) return $obj[$val];
	}
	elseif( is_object( $obj ) )
	{
		if( isset( $obj->$val ) ) return $obj->$val;	
	}
	
	if( $def ) return $def;
	else return false;
}

function texttoslug($string)
{
	return trim(preg_replace("#([^a-z0-9])#i","_",strtolower($string)));
}




