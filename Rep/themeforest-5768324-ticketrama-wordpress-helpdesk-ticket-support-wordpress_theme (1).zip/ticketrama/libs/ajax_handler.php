<?php

class FW_ajax_handler extends fw_options
{
	
	var $fields = '';
	var $msgs = '';
	var $form_action = '';
	
	
	function __construct()
	{

		add_action( 'wp_ajax_fw_ajax_callback', array( $this, 'ajax' ), 10, 1 );
		add_action( 'wp_ajax_nopriv_fw_ajax_callback', array( $this, 'ajax' ), 10, 1 );
	}
	
	function ajax($data)
	{
		$type = kvalue( $_REQUEST, 'type' );
		//$this->form_action = admin_url('admin-ajax.php?action=fw_ajax_callback');
		
		include( 'config/config.php');
		$this->fields = $options;

		if( method_exists( $this, $type ) ) $this->$type($_REQUEST);
		exit;
	}
	
	function ticketform($data = array())
	{
		$fields = kvalue( $this->fields, kvalue( $data, 'type') );
		
		$settings = array();
		
		$this->form_action['type'] = 'submit_ticket';
		
		if( kvalue( $data, 'subaction' ) == 'edit' && kvalue( $data, 'post_id' ) ){
			$post = get_post( kvalue( $data, 'post_id' ) );
			
			if( $post ) {
				if( is_user_logged_in() ) {
				
					$cats =  wp_get_post_categories( kvalue( $post, 'ID' ) );
					$settings['title'] = kvalue( $post, 'post_title' );
					$settings['category'] = ( $cats ) ? kvalue(current( (array) $cats ), 'term_id' ) : '';
					$settings['text'] = apply_filters('the_content', kvalue( $post, 'post_content' ) );
					$this->form_action = array_merge(array('type'=>'submit_ticket', 'subaction'=>'edit', 'post_id'=>kvalue($post,'ID')), $this->form_action);
				}else $this->msgs[] = array('type'=>'error', 'msg'=> '<h6 class="invalid">You are not authorized to edit this post</h6>');
			}
			
		}

		if( !is_user_logged_in() ) $fields = array_merge( $fields, kvalue( $this->fields, 'login' ) );
		
		$this->generate_html($fields, $settings );
	}
	
	
	function fb_login()
	{
		
		$existing = get_user_by( 'email', kvalue( $_POST, 'email' ) );

		if( isset($existing->ID))
		{
			wp_set_auth_cookie( $existing->ID );
			exit('success');
		}
		
		if( !isset($existing->ID))
		{
			$username = (!username_exists(kvalue($_POST, 'user_name'))) ? 'username' : 'email';
			$password = wp_generate_password( 12, true );
			
			$options = array('user_login'=>$username, 'user_nicename'=>'name', 'user_url'=>'link', 'user_email'=>'email', 'display_name'=>'name','nickname'=>'name',
						'first_name'=>'first_name', 'last_name'=>'last_name', 'description'=>'', 'role' => 'video_contributor');
			$data = array();
			foreach( $options as $k => $v)
			{
				if( kvalue($_POST, $v ) ) $data[$k] = kvalue($_POST, $v);
			}

			$user_id = '';
			if( $data ) 
			{
				$data['user_pass'] = $password;
				$user_id = wp_insert_user($data);
			}
			
			if( !is_wp_error($user_id))
			{
				update_user_meta( $user_id, 'user_gender', kvalue($_POST, 'gender') );
				wp_set_auth_cookie( $user_id );
				$message = sprintf( __("Your new user is created, Details are \nusername is: \t %s \npassword is: \t %s", AM_THEMES), kvalue($_POST, $username), $password );

				wp_new_user_notification( $user_id, $password );

				exit('success');
			}
			exit('failed');
		}
		exit('failed');
		//wp_redirect( home_url() );exit;
	}
	
	
	function generate_html($options, $settings, $layout = '')
	{	
		$return = array();
		
		foreach( $options as $k => $v )
		$return[$k] = $this->html_generator($k, $v, $settings, true);
		
		if( $this->msgs ) $return['msg'] = $this->msgs;
		
		$return['form_action'] = add_query_arg($this->form_action, admin_url('admin-ajax.php?action=fw_ajax_callback'));
		$layout = !( $layout ) ? get_template_directory().'/libs/views/form.php' : $layout;
		
		include( $layout );
	}
	
	function json_res( $msg, $type = 'success', $refresh = false )
	{
		exit( json_encode( array('type'=>$type, 'msg'=>$msg, 'refresh'=>$refresh ) ) );
	}
	
	
	function submit_ticket($data)
	{
		$post_id = kvalue( $data, 'post_id' );
		$current_user = wp_get_current_user();
		//printr($current_user);
		if( !is_user_logged_in() ) if( !current_user_can( 'edit_posts' ) ) $this->json_res( __('<h6 class="invalid">You are not authorized to manage ticket</h6>', AM_THEMES), 'error');
		
		$post_status = in_array('administrator', kvalue( $current_user, 'roles') ) ? 'publish' : 'pending';
		if( kvalue( $_POST, 'subaction' ) == 'edit' ){
			if( !current_user_can( 'edit_posts', $post_id ) ) $this->json_res( __('<h6 class="invalid">You are not authorized to manage ticket</h6>', AM_THEMES), 'error');
		}//else {
			//if( !current_user_can( 'edit_posts' ) ) $this->json_res( __('<h6 class="invalid">You are not authorized to manage ticket</h6>', AM_THEMES), 'error');
		//}
		
		if( !kvalue( $data, 'title'))	$this->json_res( __('<h6 class="invalid">Title field is required, Enter appropriate title for the ticket</h6>', AM_THEMES), 'error');
		
		if( !kvalue( $data, 'text') )	$this->json_res( __('<h6 class="invalid">Ticket content is required, Enter appropriate content</h6>', AM_THEMES), 'error');
		
		if( !$post_id && kvalue( $data, 'subaction') == 'edit' ) $this->json_res( __('<h6 class="invalid">The ticket you are trying to submit is invalid</h6>', AM_THEMES), 'error');
		
		$post = array('post_title'=>kvalue( $data, 'title'), 'post_content'=>kvalue( $data, 'text' ), 'post_category'=>array(kvalue($data, 'category')),
				'post_type'=>'ticket', 'post_author'=> kvalue( $current_user, 'ID', 1), 'post_status'=> 'publish' );
				
		if( kvalue( $data, 'subaction') == 'edit' && $post_id ) $post['ID'] = $post_id;
		
		$id = wp_insert_post( $post );
		
		if( is_wp_error( $id ) && is_array( $user_id->get_error_messages() ) ){
			$msg = '';
			foreach($user_id->get_error_messages() as $message)	$msg .= '<h6 class="invalid">'.$message.'</h6>';
			$this->json_res($msg, 'error');
		}
		
		$this->json_res( __('<h6 class="valid add-left add-right">Your ticket is updated successfully</h6>', AM_THEMES), 'success');
	}
	
	
	function ticketdelete($data)
	{
		$post_id = kvalue( $data, 'post_id' );
		$current_user = wp_get_current_user();
		
		if( !current_user_can( 'delete_post', $post_id ) ) $this->json_res( __('<h6 class="invalid">You are not authorized to manage tickets</h6>', AM_THEMES), 'error');
		
		if( wp_delete_post( $post_id ) ) $this->json_res( __('<h6 class="valid">Ticket is deleted successfully</h6>', AM_THEMES), 'success');
		else $this->json_res( __('Unable to delete ticket', AM_THEMES), 'error');
	}
	
	function login_register_form($data)
	{
		if( !is_user_logged_in() ) include( 'views/register.php' );
		else echo '<div class="container">
					<div class="sixteen columns register"><h6 class="add-left invalid">'.__('You are already signed in', AM_THEMES).'</h6></div></div>';
		exit;
	}
	
	function login_register($data)
	{
		

		if( is_user_logged_in() ) $this->json_res( __('<h6 class="add-top add-left invalid">You are already logged in</h6>', AM_THEMES), 'error');
		
		
		if( $register = kvalue( $data, 'subaction' ) == 'register' ){
			$user_id = username_exists( kvalue( $_POST, 'user_login') );
			if(!is_email(kvalue( $_POST, 'user_email')))
			{ 
			
				$this->json_res( __('<h6 class="add-top add-left invalid">Please enter valid email!</h6>', AM_THEMES), 'error');
		
			}elseif( !$user_id and email_exists(kvalue( $_POST, 'user_email')) == false ) {
				
					$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
					$user_id = wp_create_user( kvalue( $_POST, 'user_login') , $random_password, kvalue( $_POST, 'user_email') );
					
					if( !is_wp_error($user_id))
					{
						//wp_set_auth_cookie( $user_id );
						wp_new_user_notification( $user_id, $random_password );
						$this->json_res( __('<h6 class="add-top add-left add-right valid">Your username is successfully created, Check your email for more detail</h6>', AM_THEMES), 'success');
					}
			} else {
				$random_password = $this->json_res( __('<h6 class="add-top add-left invalid">Username already exists, password inherited</h6>', AM_THEMES), 'error');
			}
		}
		elseif( $register = kvalue( $data, 'subaction' ) == 'login' ){
			$auth = wp_authenticate( kvalue( $_POST, 'log' ), kvalue( $_POST, 'pwd' ) );
			if( !is_wp_error($auth)){
				wp_set_auth_cookie( kvalue( $auth, 'ID') );
				$this->json_res( __('<h6 class="add-top add-left add-right valid">Login successful</h6>', AM_THEMES), 'success', true);
			}else{
				$error = '';
				foreach($auth->get_error_messages() as $message)	$error .= '<h6 class="add-top add-left invalid">'.$message.'</h6>';
				$this->json_res($error, 'error');
			}
		}
	}
}

new FW_ajax_handler;