<?php
global $post;
if ( post_password_required() )
	return;
?>

<div id="comments" class="dub-bottom">

	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
				( kvalue( $post, 'post_type' ) == 'ticket' ) ? _e('Answers', AM_THEMES) : comments_number();
			?>
		</h2>

		<?php
            wp_list_comments( array(
                'style'       => 'div',
                'short_ping'  => true,
                'avatar_size' => 74,
				'callback' => 'fw_list_comments'
            ) );
        ?>


		<?php
			// Are there comments to navigate through?
			if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
		?>
		<nav class="navigation comment-navigation" role="navigation">
			<h1 class="screen-reader-text section-heading"><?php _e( 'Comment navigation', AM_THEMES ); ?></h1>
			<div class="nav-previous"><?php previous_comments_link( __( '&larr; Older Comments', AM_THEMES ) ); ?></div>
			<div class="nav-next"><?php next_comments_link( __( 'Newer Comments &rarr;', AM_THEMES ) ); ?></div>
		</nav><!-- .comment-navigation -->
		<?php endif; // Check for comment navigation ?>

		<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p class="no-comments"><?php _e( 'Comments are closed.' , AM_THEMES ); ?></p>
		<?php endif; ?>

	<?php endif; // have_comments() ?>

	<?php fw_comment_form(); ?>

</div><!-- #comments -->