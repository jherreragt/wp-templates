<?php get_header();
$settings = get_option(THEME_PREFIX.'sidebar_settings'); ?>

<div id="breadcrumb">
    <div class="container">
        <div class="sixteen columns">
            <div class="right">
               <?php echo fw_get_searchform();?>
            </div>
            <h4 class="grey bold">
            	<?php printf( __( 'Category Archives: %s', AM_THEMES), single_cat_title( '', false ) ); ?>
            </h4>
            
        </div>
    </div>
</div>
<div class="container dub-top">
    <div class="ten columns dub-bottom">
    	
        <?php if ( category_description() ) : // Show an optional category description ?>
            <h5 class="page-hading half-bottom"><?php _e('Category Description', AM_THEMES); ?></h5>
            <div class="archive-meta"><?php echo category_description(); ?></div>
        <?php endif; ?>
        
        <h5 class="page-hading"><?php _e('Newest posts', AM_THEMES );?></h5>
        
        <ul class="news-list">
            <?php while( have_posts() ): the_post(); ?>
            	<?php include( 'libs/blog_listing.php' ); ?>
            <?php endwhile; ?>
        </ul>
        
        <!-- POSTS NAVIGATION -->
        <?php fw_the_pagination(); ?>
    </div>
    <div class="five columns offset-by-one dub-bottom">
        <?php dynamic_sidebar( kvalue( $settings, 'category', 'blog') ); ?>
    </div>
</div>
<?php get_footer();?>
