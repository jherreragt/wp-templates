<?php get_header();
$settings = get_option(THEME_PREFIX.'sidebar_settings'); ?>

<div id="breadcrumb">
    <div class="container">
        <div class="sixteen columns">
            <div class="right">
               <?php echo fw_get_searchform();?>
            </div>
            <h4 class="grey bold">
            	<?php printf( __( 'Search Results for: %s', AM_THEMES ), get_search_query() ); ?>
            </h4>
        </div>
    </div>
</div>
<div class="container dub-top">
    <div class="ten columns dub-bottom">
    	<?php if( have_posts() ): ?>
            <h5 class="page-hading"><?php _e('Newest posts', AM_THEMES );?></h5>
            
            <ul class="news-list">
                <?php while( have_posts() ): the_post(); ?>
                    <?php include( 'libs/blog_listing.php' ); ?>
                <?php endwhile; ?>
            </ul>
            
            <!-- POSTS NAVIGATION -->
            <?php fw_the_pagination(); ?>
            
        <?php else: ?>
        	
            <h5 class="page-hading"><?php _e('No results found', AM_THEMES );?></h5>
            <p><?php _e( 'Sorry, but nothing matched your search terms. Please try again with different keywords.', AM_THEMES ); ?></p>
        <?php endif; ?>
    </div>
    <div class="five columns offset-by-one dub-bottom">
        <?php dynamic_sidebar( kvalue( $settings, 'sidebar', 'search' ) ); ?>
    </div>
</div>
<?php get_footer();?>
