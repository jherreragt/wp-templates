<?php /* Template Name: Contact Page */
get_header(); 

$contact_settings = get_option(THEME_PREFIX.'contact_page_settings');?>

<div id="breadcrumb">
	<div class="container">
		<div class="sixteen columns">
			<div class="right">
				<?php echo fw_get_searchform();?>
			</div>
			<h4 class="grey bold"><?php the_title(); ?></h4>
		</div>
	</div>
</div>

<div class="bg1" id="headquaters" style="background-image:url(<?php echo kvalue($contact_settings, 'contact_background');?>);" >
	<div class="container">
    	
        <?php if( $heading = kvalue( $contact_settings, 'heading' ) ): ?>
			<h2 class="l-grey2 text-center"><?php echo $heading; ?></h2>
        <?php endif; ?>
		<div class="transbox sixteen columns">
			<div class="solidbox2">
				<div class="hq-info text-left left">
					
                    <?php if( $office = kvalue( $contact_settings, 'office' ) ): ?>
                    	<h3 class="white bold dub-bottom"><?php echo $office; ?></h3>
                    <?php endif; ?>
					
                    <?php if( $company = kvalue( $contact_settings, 'company' ) ): ?>
                    	<h6 class="opensans-bold white"><?php echo $company; ?></h6>
                    <?php endif; ?>
                    
                    <?php if( $address = kvalue( $contact_settings, 'contact_address' ) ): ?>
						<h6 class="opensans-bold white dub-bottom"><?php echo $address; ?></h6>
					<?php endif; ?>
                    <?php if( $phone = kvalue( $contact_settings, 'contact_phone' ) ): ?>
						<h6 class="opensans-bold white"><span class="add-right"><?php _e('PHONE', AM_THEMES); ?></span><?php echo $phone; ?></h6>
                    <?php endif; ?>
                    
                    <?php if( $email = kvalue( $contact_settings, 'contact_to' ) ): ?>
						<h6 class="opensans-bold white"><span class="add-right"><?php _e('EMAIL', AM_THEMES); ?></span><?php echo $email; ?></h6>
                    <?php endif; ?>
                    
				</div>
				<div class="right">
					<?php echo kvalue( $contact_settings, 'google_map' ); ?>
				</div>
				<div class="clear"></div>
			</div>
		</div>            
	</div>
</div>

<div class="section-normal" id="hello">
	<div class="container">
		<?php while( have_posts() ): the_post();
		the_content();
		endwhile; ?>
	</div>
</div>

<?php get_footer(); ?>