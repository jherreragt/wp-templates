<?php 
/* Template Name: Home */
?>
<?php get_header();?>

<?php $home_page_settings = get_option(THEME_PREFIX.'home_page_settings');?>

<div id="searchsubmit" style="background-image:url(<?php echo kvalue($home_page_settings, 'background');?>);" class="bg1">

	<div class="container">
    	<?php if(kvalue($home_page_settings, 'search_box') == 'active'):?>
        
            <div class="transbox seven columns">
                <div id="searchbox" class="solidbox">
                    <h3 class="l-grey bold"><?php echo __('SEARCH', AM_THEMES); ?></h3>
                    <form id="search_form" action="<?php echo home_url();?>" class="search" method="get">
                        <span class="search-input">
                        	<input type="text" name="s" value="type here" onblur="if(this.value == '') { this.value='type here'}" onfocus="if (this.value == 'type here') {this.value=''}"/>
                    	</span>
                        <input class="coral-btn" type="submit" value="search">
                    </form>
                </div>
            </div>
            
        <?php endif;?>
        
        <?php if(kvalue($home_page_settings, 'search_box') == 'active' && kvalue($home_page_settings, 'ticket_box') == 'active'):?>
        
            <div class="two columns text-center">
                <div>
                    <h3 class="or white bold"><?php echo __('OR', AM_THEMES);?></h3>
                </div>
            </div> 
        <?php endif;?> 
        
        <?php if(kvalue($home_page_settings, 'ticket_box') == 'active'):?>
        
            <div id="submitbox" class="transbox seven columns">
                <div class="solidbox">
                    <h3 class="bold white"><a class="ajax-data" href="<?php echo admin_url('admin-ajax.php?action=fw_ajax_callback&type=ticketform');?>"><?php echo __('SUBMIT TICKET', AM_THEMES); ?></a></h3>
                    <div class="cross2">
                    	<a class="ajax-data" href="<?php echo admin_url('admin-ajax.php?action=fw_ajax_callback&type=ticketform');?>">
                        	<img src="<?php echo get_template_directory_uri(); ?>/images/plus-big.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
            
        <?php endif;?>   
                   
	</div>
    
</div>
<?php while( have_posts() ): the_post();
	the_content(); 
endwhile;?>

<?php get_footer();?>