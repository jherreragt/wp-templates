<?php get_header();
$settings = get_option(THEME_PREFIX.'sidebar_settings'); ?>

<div id="breadcrumb">
    <div class="container">
        <div class="sixteen columns">
            <div class="right">
                <form class="headsearch" method="get">
                    <input type="text" onfocus="if (this.value == '<?php _e('Search Here', AM_THEMES );?>') {
                                this.value = ''
                            }" onblur="if (this.value == '') {
                                this.value = '<?php _e('Search Here', AM_THEMES );?>'
                            }" value="<?php _e('Search Here', AM_THEMES );?>" class="headsearch" name="s">
                </form>
            </div>
            <h4 class="grey bold">
            	<?php printf( __( 'Tag Archives: %s', AM_THEMES ), single_tag_title( '', false ) ); ?>
            </h4>
        </div>
    </div>
</div>
<div class="container dub-top">
    <div class="ten columns dub-bottom">
    	
        <?php if ( tag_description() ) : // Show an optional tag description ?>
        	<h5 class="page-hading half-bottom"><?php _e('Tag Description', AM_THEMES); ?></h5>
            <div class="archive-meta"><?php echo tag_description(); ?></div>
        <?php endif; ?>
    	
        <h5 class="page-hading"><?php _e('Newest posts', AM_THEMES );?></h5>
        
        <ul class="news-list">
            <?php while( have_posts() ): the_post(); ?>
            	<?php include( 'libs/blog_listing.php' ); ?>
            <?php endwhile; ?>
        </ul>
        
        <!-- POSTS NAVIGATION -->
        <?php fw_the_pagination(); ?>
    </div>
    <div class="five columns offset-by-one dub-bottom">
        <?php dynamic_sidebar( kvalue( $settings, 'tags', 'blog') ); ?>
    </div>
</div>
<?php get_footer();?>
