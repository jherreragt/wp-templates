<?php $general_settings = get_option(THEME_PREFIX.'general_settings');?>
<div id="contact">
	<div class="container text-center">
		<h5 class="lime half-bottom"><?php echo stripslashes(kvalue($general_settings, 'call_message')); ?></h5>
		<h4 class="white"><?php echo kvalue($general_settings, 'call_action'); ?><span class="green"><?php echo _e(' or ', AM_THEMES);?></span><?php echo kvalue($general_settings, 'call_email');?></h4>
	</div>
</div>
<div id="footer">
	<div class="container">
		<?php if(dynamic_sidebar('footer_sidebar')):?>
        <?php endif;?>
    </div>
</div>

<div id="copyright">
	<div class="container">
		<div class="sixteen columns">
			<?php echo kvalue($general_settings, 'copyright'); ?>
		</div>
	</div>
</div>

<?php wp_footer();?>