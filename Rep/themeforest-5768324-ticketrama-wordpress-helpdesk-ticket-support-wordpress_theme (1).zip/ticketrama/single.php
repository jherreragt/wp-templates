<?php get_header();
$settings = get_post_meta(get_the_ID(), 'wpnukes_post_settings', true);?>

<div id="breadcrumb">
    <div class="container">
        <div class="sixteen columns">
            <div class="right">
               <?php echo fw_get_searchform();?>
            </div>
            <h4 class="grey bold"><?php __('Blog / News', AM_THEMES);?></h4>
        </div>
    </div>
</div>

<div class="container dub-top">
    <div class="ten columns dub-bottom">

        <ul class="news-list">

            <?php while( have_posts() ): the_post(); ?>
            <li id="post-<?php the_ID(); ?>" <?php post_class('news-item single-post clearfix'); ?>>
                <figure class="media-object">
                    <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail(); ?></a>
                    <figcaption class="caption clearfix">
                        <div class="news-date left">
                            <img class="icon" src="<?php echo get_template_directory_uri(); ?>/images/calendar.png" alt=""/>
                            <a href="<?php echo get_month_link(get_the_date('Y'), get_the_date('m')); ?>"><?php the_date(); ?></a>
                        </div>
                        <div class="news-comments right">
                            <img class="icon" src="<?php echo get_template_directory_uri(); ?>/images/comments.png" alt=""/>
                            <a href="#comments"><?php comments_number(); ?></a>
                        </div>
                    </figcaption>
                </figure>
                <h5 class="news-title opensans-bold">
                    <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                </h5>
                <p class="news-excerpt opensans">
                    <?php the_content(); ?> 
                </p>
            </li>
        </ul>

        <?php if( defined('BLOG_SHARING') && BLOG_SHARING == 'on' ): ?>
            <!-- SOCIAL SHARING -->
            <div class="social-sharing">
                <span class="social-label opensans-bold"><?php _e('Sharing is caring', AM_THEMES); ?></span>
                <div class="social-buttons right">
                    <!-- AddThis Button BEGIN -->
                    <div class="addthis_toolbox addthis_default_style social-wrapper">
                        <a class="addthis_button_facebook_like"></a>
                        <a class="addthis_button_tweet"></a>
                        <a class="addthis_button_google_plusone"></a> 
                        <a class="addthis_button_linkedin_counter"></a>
                    </div>
                    <script type="text/javascript">var addthis_config = {"data_track_addressbar": true};</script>
                    <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-4fa4d8fa088d64c0"></script>
                    <!-- AddThis Button END -->
                </div>
            </div>
        <?php endif; ?>
        
        <?php if( defined('BLOG_AUTHOR') && BLOG_AUTHOR == 'on' ): ?>
            <div class="dub-bottom clearfix" id="author">
            
                <h5 class="opensans-bold add-bottom grey"><?php _e('About author', AM_THEMES); ?></h5>
                
                <?php if( $auth_image = get_user_meta( kvalue( $post, 'post_author'), '_profile_image', true ) ): ?>
                    <img src="<?php echo $auth_image; ?>" width="96" class="avatar" />
                <?php else: 
                    echo get_avatar( kvalue( $post, 'post_author'), 96 ); 
                endif; ?>
                
                <div class="content">
                    <h5 class="opensans-bold half-bottom grey inline"><?php the_author(); ?></h5>
                    
                    <?php if( $fb = get_user_meta(kvalue( $post, 'post_author'), 'facebook', true) ): ?>
                        <a href="<?php echo $fb; ?>" title="Facebook">
                            <img alt="" src="<?php echo get_template_directory_uri(); ?>/images/twitter-ico.png">
                        </a>
                    <?php endif; ?>
                    
                    <?php if( $twitter = get_user_meta(kvalue( $post, 'post_author'), 'twitter', true) ): ?>
                        <a href="<?php echo $twitter; ?>" title="Twitter">
                            <img alt="" src="<?php echo get_template_directory_uri(); ?>/images/in-ico.png">
                        </a>
                    <?php endif; ?>
                    
                    <p class="opensans"><?php the_author_meta('description'); ?></p>
                </div>
            </div>
        <?php endif; ?>
        
        <?php wp_link_pages(); ?>
		<?php endwhile; ?>
        
        <?php comments_template(); ?>

	</div>

	<div class="five columns offset-by-one dub-bottom">
    	<?php dynamic_sidebar( kvalue( $settings, 'sidebar', 'blog' ) ); ?>
    </div>

</div>

<?php get_footer(); ?>

