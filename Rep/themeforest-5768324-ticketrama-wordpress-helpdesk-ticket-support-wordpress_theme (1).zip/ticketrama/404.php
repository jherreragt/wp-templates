<?php get_header();?>

<div id="breadcrumb">
	<div class="container">
		<div class="sixteen columns">
			<h4 class="grey bold"><?php _e( 'Not found', AM_THEMES ); ?></h4>
		</div>
	</div>
</div>

<div class="section-normal">
	<div class="container">
    	
        <h2><?php _e( 'Error 404', AM_THEMES ); ?></h2>
		<p><?php _e( "Ooops! Looks like you're searching for something that's not here", AM_THEMES ); ?></p>
        
    </div>
</div>


<?php get_footer();?>