<?php /* Template Name: Profile */

if( !is_user_logged_in() ) return;

$current_user = wp_get_current_user(); //printr($current_user);
get_header(); 
$settings = get_post_meta(get_the_ID(), 'wpnukes_ticket_settings', true);?>

<div id="breadcrumb">
    <div class="container">
        <div class="sixteen columns">
            <div class="right">
               <?php echo fw_get_searchform();?>
            </div>
            <h4 class="grey bold"><?php the_title(); ?></h4>
        </div>
    </div>
</div>

<div class="container dub-top">

    <div class="ten columns dub-bottom">
        
		<?php $args = array( 'post_type' => 'ticket', 'paged'=>get_query_var('paged') );
		if( !in_array('administrator', kvalue( $current_user, 'roles' ) ) ) $args['author'] = kvalue( $current_user, 'ID');
		$query = new WP_Query( $args ); //printr($query);exit;?>
		<?php if( $query->have_posts() ): ?>
            
            <h5 class="page-hading left"><?php _e('Your Tickets', AM_THEMES); ?></h5>
            <span class="logged-user opensans left"><?php printf(__('( You are logged as @%s )', AM_THEMES), kvalue( $current_user, 'user_login') ); ?> </span>            

        
			<?php while( $query->have_posts() ): $query->the_post(); ?>
				<div class="ten columns latest-topics alpha omega">
					<div class="row-top">
						<?php $comment = wp_count_comments( get_the_ID() );?>
						<div class="right"><h5 class="opensans-bold"><?php echo kvalue( $comment, 'approved'); ?></h5></div>
						<h6 class="opensans"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
					</div>
					<div class="row-bottom">
						<?php $com = get_comments(array('number'=>1, 'post_id'=>get_the_ID())); ?>
						<?php if( $com ): ?>	
							<h6 class="opensans grey">
								<?php _e('Last comment', AM_THEMES);?> 
								<?php echo date(get_option('date_format'), strtotime(kvalue( kvalue($com, 0), 'comment_date_gmt'))); ?>
								<?php _e('by', AM_THEMES);?> <span class="user-author"><?php the_author(); ?></span>
                               	
                                <?php if( get_post_meta( get_the_ID(), 'wpnukes_ticket_status', true ) == 'solved' ): ?>
                                	<span class="solution-label opensans-bold right half-left"><?php _e('Solved', AM_THEMES); ?></span>
                                <?php endif; ?>
                                
							</h6>
						<?php else: ?>
                        	<h6><?php _e('No Reply yet on this topic', AM_THEMES); ?>
                            
							<?php if( get_post_meta( get_the_ID(), 'wpnukes_ticket_status', true ) == 'solved' ): ?>
                            	<span class="solution-label opensans-bold right half-left"><?php _e('Solved', AM_THEMES); ?></span></h6>
                            <?php endif; ?>
                            
						<?php endif; ?>
                        
					</div>
				</div>
			<?php endwhile; ?>
			<?php fw_the_pagination(array('total'=>$query->max_num_pages)); ?>
        
		<?php else: ?>
            <h5 class="page-hading"><?php _e('No ticket found', AM_THEMES );?></h5>
            <p><?php _e( 'It seems you still have not created any ticket.', AM_THEMES ); ?></p>
        <?php endif; ?>
        
	</div>
    
    <!-- Sidebar -->
    <div class="five columns offset-by-one dub-bottom">      
		<?php dynamic_sidebar(kvalue( $settings, 'sidebar', 'blog' )); ?>
    </div>
    
</div>
<?php get_footer(); ?>



