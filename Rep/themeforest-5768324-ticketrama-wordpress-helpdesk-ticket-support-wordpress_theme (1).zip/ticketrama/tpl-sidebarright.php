<?php /* Template Name: Sidebar Right */

get_header();
$settings = get_post_meta(get_the_ID(), 'wpnukes_post_settings', true);
?>

<div id="breadcrumb">
    <div class="container">
        <div class="sixteen columns">
            <div class="right">
                <?php echo fw_get_searchform();?>
            </div>
            <?php echo get_the_breadcrumb();?>
        </div>
    </div>
</div>

<div class="container dub-top">
     <div class="ten columns dub-bottom">
     	<h3 class="opensans-bold grey add-bottom"><?php the_title(); ?></h3>
          <figure class="media-object dub-bottom">
              <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail(); ?></a>
          </figure>
		<?php while( have_posts() ): the_post();
               the_content(); 
          endwhile;?>
   	</div>
     <div class="five columns offset-by-one dub-bottom">
    		<?php dynamic_sidebar( kvalue( $settings, 'sidebar', 'blog' ) ); ?>
    	</div>
</div>



<?php get_footer(); ?>