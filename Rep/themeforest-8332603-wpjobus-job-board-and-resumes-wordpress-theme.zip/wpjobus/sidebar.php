<?php if ( !function_exists('dynamic_sidebar')
    || !dynamic_sidebar('page') ) : ?>
<?php endif; ?>